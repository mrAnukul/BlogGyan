package com.examly.springapp.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.examly.springapp.model.Comment;
import java.util.List;

/**
 * The CommentRepo interface is a repository interface for managing Comment entities.
 * It extends JpaRepository to provide CRUD operations on Comment entities.
 */
public interface CommentRepo extends JpaRepository<Comment, Long> {

    /**
     * Finds comments by the blog post ID and includes user information.
     * 
     * @param blogPostId The ID of the blog post.
     * @return A list of comments for the specified blog post.
     */
    @Query("SELECT c FROM Comment c JOIN FETCH c.user WHERE c.blogPost.blogPostId = :blogPostId")
    List<Comment> findCommentsByBlogPostId(@Param("blogPostId") Long blogPostId);
}
