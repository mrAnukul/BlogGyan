package com.examly.springapp.service;

import java.util.List;
import com.examly.springapp.exception.CommentNotFoundException;
import com.examly.springapp.model.Comment;

public interface CommentService {
   List<Comment> getCommentsByBlogPostId(Long blogPostId) throws CommentNotFoundException;
   Comment addComment(Comment comment);
   boolean deleteComment(Long commentId) throws CommentNotFoundException;
}
