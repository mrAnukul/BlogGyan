package com.examly.springapp.service;

import java.util.List;
import com.examly.springapp.exception.FeedbackNotFoundException;
import com.examly.springapp.exception.UserNotFoundException;
import com.examly.springapp.model.Feedback;

/**
 * The FeedbackService interface defines the operations for managing Feedback entities.
 * It provides methods to add, retrieve, edit, and delete feedbacks.
 */
public interface FeedbackService {

    /**
     * Adds a new feedback.
     * 
     * @param feedback The feedback to be added.
     * @return The added feedback.
     * @throws UserNotFoundException if the user associated with the feedback is not found.
     */
    Feedback addFeedback(Feedback feedback) throws UserNotFoundException;

    /**
     * Retrieves all feedbacks.
     * 
     * @return A list of all feedbacks.
     */
    List<Feedback> getAllFeedback();

    /**
     * Retrieves all feedbacks by the user ID.
     * 
     * @param userId The ID of the user.
     * @return A list of feedbacks provided by the specified user.
     * @throws UserNotFoundException if the user with the specified ID is not found.
     */
    List<Feedback> getAllFeedbackByUserId(Long userId) throws UserNotFoundException;

    /**
     * Edits an existing feedback.
     * 
     * @param feedbackId The ID of the feedback to be edited.
     * @param updatedFeedback The updated feedback details.
     * @return The updated feedback.
     * @throws FeedbackNotFoundException if the feedback with the specified ID is not found.
     */
    Feedback editFeedback(Long feedbackId, Feedback updatedFeedback) throws FeedbackNotFoundException;

    /**
     * Deletes an existing feedback.
     * 
     * @param feedbackId The ID of the feedback to be deleted.
     * @return The deleted feedback.
     * @throws FeedbackNotFoundException if the feedback with the specified ID is not found.
     */
    Feedback deleteFeedback(Long feedbackId) throws FeedbackNotFoundException;
}
