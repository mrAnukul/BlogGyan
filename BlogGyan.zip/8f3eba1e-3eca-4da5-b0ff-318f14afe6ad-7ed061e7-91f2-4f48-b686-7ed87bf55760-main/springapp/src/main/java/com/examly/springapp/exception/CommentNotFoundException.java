package com.examly.springapp.exception;

/**
 * The CommentNotFoundException class is a custom exception
 * that is thrown when an attempt is made to access a comment
 * that is not found.
 */
public class CommentNotFoundException extends RuntimeException {

    /**
     * Default constructor for the CommentNotFoundException class.
     */
    public CommentNotFoundException() {
        super();
    }

    /**
     * Parameterized constructor for the CommentNotFoundException class.
     * 
     * @param message The error message associated with the exception.
     */
    public CommentNotFoundException(String message) {
        super(message);
    }
}

