package com.examly.springapp.exception;

/**
 * The FeedbackNotFoundException class is a custom exception
 * that is thrown when an attempt is made to access feedback
 * that is not found.
 */
public class FeedbackNotFoundException extends Exception {

    /**
     * Default constructor for the FeedbackNotFoundException class.
     */
    public FeedbackNotFoundException() {
        super();
    }

    /**
     * Parameterized constructor for the FeedbackNotFoundException class.
     * 
     * @param message The error message associated with the exception.
     */
    public FeedbackNotFoundException(String message) {
        super(message);
    }
}
