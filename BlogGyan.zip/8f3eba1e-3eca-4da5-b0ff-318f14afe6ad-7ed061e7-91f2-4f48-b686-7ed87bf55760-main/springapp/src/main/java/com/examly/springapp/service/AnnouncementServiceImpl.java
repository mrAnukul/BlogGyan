package com.examly.springapp.service;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import com.examly.springapp.exception.AnnouncementAlreadyExistsException;
import com.examly.springapp.exception.AnnouncementNotFoundException;
import com.examly.springapp.model.Announcement;
import com.examly.springapp.repository.AnnouncementRepo;

/**
 * The AnnouncementServiceImpl class implements the AnnouncementService interface
 * and provides the business logic for managing Announcement entities.
 */
@Service
public class AnnouncementServiceImpl implements AnnouncementService {

    private static final Logger logger = LoggerFactory.getLogger(AnnouncementServiceImpl.class);

    @Autowired
    AnnouncementRepo announcementRepo;

    @Value("${error.announcement.notfound}")
    private String errorMessageNotFound;

    @Value("${error.announcement.notfound.delete}")
    private String errorMessageNotFoundDelete;

    @Value("${error.announcement.notfound.update}")
    private String errorMessageNotFoundUpdate;

    @Value("${logger.announcement.adding}")
    private String loggerMessageAdding;

    @Value("${logger.announcement.deleting.notfound}")
    private String loggerMessageDeletingNotFound;

    @Value("${logger.announcement.deleting}")
    private String loggerMessageDeleting;

    @Value("${logger.announcement.updating.notfound}")
    private String loggerMessageUpdatingNotFound;

    @Value("${logger.announcement.updating}")
    private String loggerMessageUpdating;

    @Value("${logger.announcement.fetching}")
    private String loggerMessageFetching;

    @Value("${logger.announcement.fetching.notfound}")
    private String loggerMessageFetchingNotFound;

    @Value("${logger.announcement.fetching.byid}")
    private String loggerMessageFetchingById;

    /**
     * Adds a new announcement.
     * 
     * @param announcement The announcement to be added.
     * @return The added announcement.
     * @throws AnnouncementAlreadyExistsException if the announcement already exists.
     */
    @Override
    public Announcement addAnnouncement(Announcement announcement) {
        logger.info(loggerMessageAdding, announcement.getTitle());
        return announcementRepo.save(announcement);
    }

    /**
     * Deletes an existing announcement.
     * 
     * @param announcementId The ID of the announcement to be deleted.
     * @return The deleted announcement.
     * @throws AnnouncementNotFoundException if the announcement with the specified ID is not found.
     */
    @Override
    public Announcement deleteAnnouncement(Long announcementId) throws AnnouncementNotFoundException {
        Announcement deletedAnnouncement = announcementRepo.findById(announcementId).orElse(null);
        if (deletedAnnouncement==null) {
            logger.error(loggerMessageDeletingNotFound, announcementId);
            throw new AnnouncementNotFoundException(errorMessageNotFoundDelete);
        }
        announcementRepo.deleteById(announcementId);
        logger.info(loggerMessageDeleting, announcementId);
        return deletedAnnouncement;
    }

    /**
     * Edits an existing announcement.
     * 
     * @param announcementId The ID of the announcement to be edited.
     * @param updatedAnnouncement The updated announcement details.
     * @return The updated announcement.
     * @throws AnnouncementNotFoundException if the announcement with the specified ID is not found.
     */
    @Override
    public Announcement editAnnouncement(Long announcementId, Announcement updatedAnnouncement) throws AnnouncementNotFoundException {
        Announcement foundAnnouncement = announcementRepo.findById(announcementId).orElse(null);
        if (foundAnnouncement ==null) {
            logger.error(loggerMessageUpdatingNotFound, announcementId);
            throw new AnnouncementNotFoundException(errorMessageNotFoundUpdate);
        }
        updatedAnnouncement.setAnnouncementId(announcementId);
        logger.info(loggerMessageUpdating, announcementId);
        return announcementRepo.save(updatedAnnouncement);
    }

    /**
     * Retrieves all announcements.
     * 
     * @return A list of all announcements.
     * @throws AnnouncementNotFoundException if no announcements are found.
     */
    @Override
    public List<Announcement> getAllAnnouncements() throws AnnouncementNotFoundException {
        logger.debug(loggerMessageFetching);
        return announcementRepo.findAll();
    }

    /**
     * Retrieves an announcement by its ID.
     * 
     * @param announcementId The ID of the announcement to be retrieved.
     * @return The found announcement.
     * @throws AnnouncementNotFoundException if the announcement with the specified ID is not found.
     */
    @Override
    public Announcement getByAnnouncementById(Long announcementId) throws AnnouncementNotFoundException {
        Announcement foundAnnouncement = announcementRepo.findById(announcementId).orElse(null);
        if (foundAnnouncement == null) {
            logger.error(loggerMessageFetchingNotFound, announcementId);
            throw new AnnouncementNotFoundException(errorMessageNotFound);
        }
        logger.info(loggerMessageFetchingById, announcementId);
        return foundAnnouncement;
    }
}
