package com.examly.springapp.exception;

/**
 * The AnnouncementNotFoundException class is a custom exception
 * that is thrown when an attempt is made to access an announcement
 * that is not found.
 */
public class AnnouncementNotFoundException extends RuntimeException {

    /**
     * Default constructor for the AnnouncementNotFoundException class.
     */
    public AnnouncementNotFoundException() {
        super();
    }

    /**
     * Parameterized constructor for the AnnouncementNotFoundException class.
     * 
     * @param err The error message associated with the exception.
     */
    public AnnouncementNotFoundException(String err) {
        super(err);
    }
}
