package com.examly.springapp.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.examly.springapp.model.User;

/**
 * The UserRepo interface is a repository interface for managing User entities.
 * It extends JpaRepository to provide CRUD operations on User entities.
 * It also contains custom query methods to find a user by username and password, 
 * and to find a user by email.
 */
public interface UserRepo extends JpaRepository<User, Long> {

    /**
     * Finds a user by their username and password.
     * 
     * @param username The username of the user.
     * @param password The password of the user.
     * @return The user with the specified username and password, or null if no such user exists.
     */
    @Query("SELECT u FROM User u WHERE u.email = :email AND u.password = :password")
    User findByEmailAndPassword(@Param("email") String email, @Param("password") String password);

    /**
     * Finds a user by their email.
     * 
     * @param email The email address of the user.
     * @return The user with the specified email address, or null if no such user exists.
     */
    User findByEmail(String email);
}
