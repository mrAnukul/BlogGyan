package com.examly.springapp.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

import com.examly.springapp.exception.FeedbackNotFoundException;
import com.examly.springapp.exception.UserNotFoundException;
import com.examly.springapp.model.Feedback;
import com.examly.springapp.service.FeedbackService;
import jakarta.validation.Valid;
import java.util.List;

/**
 * controller acts as intermediatory between the service logic and client
 * The FeedbackController class handles HTTP requests for managing feedbacks.
 * It provides endpoints for creating, retrieving, updating, and deleting feedbacks.
 */
@RestController
@RequestMapping("/api/feedback")
public class FeedbackController {

    @Autowired
    private FeedbackService feedbackService;

    /**
     * Adds a new feedback.
     * 
     * @param feedback The feedback to be added.
     * @return The added feedback with HTTP status CREATED.
     * @throws UserNotFoundException if the user associated with the feedback is not found.
     */
    @PreAuthorize("hasAuthority('USER')")
    @PostMapping
    public ResponseEntity<Feedback> addFeedback(@Valid @RequestBody Feedback feedback) throws UserNotFoundException {
        Feedback newFeedback = feedbackService.addFeedback(feedback);
        return ResponseEntity.status(HttpStatus.CREATED).body(newFeedback);
    }

    /**
     * Retrieves all feedbacks.
     * 
     * @return A list of all feedbacks with HTTP status OK.
     */
    @GetMapping
    public ResponseEntity<List<Feedback>> getAllFeedback() {
        List<Feedback> feedbackList = feedbackService.getAllFeedback();
        return ResponseEntity.status(HttpStatus.OK).body(feedbackList);
    }

    /**
     * Retrieves all feedbacks by the user ID.
     * 
     * @param userId The ID of the user whose feedbacks are to be retrieved.
     * @return A list of feedbacks provided by the specified user with HTTP status OK.
     * @throws UserNotFoundException if the user with the specified ID is not found.
     */
    @GetMapping("/user/{userId}")
    public ResponseEntity<List<Feedback>> getAllFeedbackByUserId(@PathVariable Long userId) throws UserNotFoundException {
        List<Feedback> feedbackList = feedbackService.getAllFeedbackByUserId(userId);
        return ResponseEntity.status(HttpStatus.OK).body(feedbackList);
    }

    /**
     * Updates an existing feedback.
     * 
     * @param feedbackId The ID of the feedback to be updated.
     * @param feedback The updated feedback details.
     * @return The updated feedback with HTTP status OK.
     * @throws FeedbackNotFoundException if the feedback with the specified ID is not found.
     */
    @PreAuthorize("hasAuthority('USER')")
    @PutMapping("/edit/{feedbackId}")
    public ResponseEntity<Feedback> editFeedback(@PathVariable Long feedbackId, @Valid @RequestBody Feedback feedback) throws FeedbackNotFoundException {
        Feedback updatedFeedback = feedbackService.editFeedback(feedbackId, feedback);
        return ResponseEntity.status(HttpStatus.OK).body(updatedFeedback);
    }

    /**
     * Deletes an existing feedback.
     * 
     * @param feedbackId The ID of the feedback to be deleted.
     * @return The deleted feedback with HTTP status NO_CONTENT.
     * @throws FeedbackNotFoundException if the feedback with the specified ID is not found.
     */

    @DeleteMapping("/delete/{feedbackId}")
    public ResponseEntity<Feedback> deleteFeedback(@PathVariable Long feedbackId) throws FeedbackNotFoundException {
        Feedback deletedFeedback = feedbackService.deleteFeedback(feedbackId);
        return ResponseEntity.status(HttpStatus.NO_CONTENT).body(deletedFeedback);
    }
}
