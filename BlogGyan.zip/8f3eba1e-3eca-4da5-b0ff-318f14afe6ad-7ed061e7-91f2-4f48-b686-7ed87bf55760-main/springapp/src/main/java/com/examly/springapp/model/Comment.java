package com.examly.springapp.model;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;

/**
 * The Comment class represents a comment entity.
 * It is annotated with @Entity to map the class to a database table.
 */
@Entity
public class Comment {

    /**
     * commentId is a primary key.
     * It is generated automatically.
     */
    @Id 
    @GeneratedValue(strategy=GenerationType.AUTO)
    private Long commentId;

    /**
     * The text content of the comment.
     */
    private String commentText;

    /**
     * The blog post to which the comment belongs.
     * It is a many-to-one relationship.
     */
    @ManyToOne
    @JoinColumn(name="blog_post_id")
    private BlogPost blogPost;

    /**
     * The user who posted the comment.
     * It is a many-to-one relationship.
     */
    @ManyToOne
    @JoinColumn(name="user_id")
    private User user;

    /**
     * Default constructor for the Comment class.
     */
    public Comment() {
    }

    /**
     * Parameterized constructor for the Comment class.
     * 
     * @param commentId The ID of the comment.
     * @param commentText The text content of the comment.
     * @param blogPost The blog post to which the comment belongs.
     * @param user The user who posted the comment.
     */
    public Comment(Long commentId, String commentText, BlogPost blogPost, User user) {
        this.commentId = commentId;
        this.commentText = commentText;
        this.blogPost = blogPost;
        this.user = user;
    }

    /**
     * Gets the ID of the comment.
     * 
     * @return The ID of the comment.
     */
    public Long getCommentId() {
        return commentId;
    }

    /**
     * Sets the ID of the comment.
     * 
     * @param commentId The new ID of the comment.
     */
    public void setCommentId(Long commentId) {
        this.commentId = commentId;
    }

    /**
     * Gets the text content of the comment.
     * 
     * @return The text content of the comment.
     */
    public String getCommentText() {
        return commentText;
    }

    /**
     * Sets the text content of the comment.
     * 
     * @param commentText The new text content of the comment.
     */
    public void setCommentText(String commentText) {
        this.commentText = commentText;
    }

    /**
     * Gets the blog post to which the comment belongs.
     * 
     * @return The blog post to which the comment belongs.
     */
    public BlogPost getBlogPost() {
        return blogPost;
    }

    /**
     * Sets the blog post to which the comment belongs.
     * 
     * @param blogPost The new blog post to which the comment belongs.
     */
    public void setBlogPost(BlogPost blogPost) {
        this.blogPost = blogPost;
    }

    /**
     * Gets the user who posted the comment.
     * 
     * @return The user who posted the comment.
     */
    public User getUser() {
        return user;
    }

    /**
     * Sets the user who posted the comment.
     * 
     * @param user The new user who posted the comment.
     */
    public void setUser(User user) {
        this.user = user;
    }

    @Override
    public String toString() {
        return "Comment [commentId=" + commentId + ", commentText=" + commentText + ", blogPost=" + blogPost + ", user=" + user + "]";
    }
}
