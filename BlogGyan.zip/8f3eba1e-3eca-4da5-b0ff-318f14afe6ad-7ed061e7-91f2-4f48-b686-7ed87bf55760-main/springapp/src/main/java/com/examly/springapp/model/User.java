package com.examly.springapp.model;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.validation.constraints.Email;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.Pattern;
import jakarta.validation.constraints.Size;


/**
 * The User class represents a user entity.
 * It is annotated with @Entity to map the class to a database table.
 */
@Entity
public class User {

    /**
     * userId is a primary key.
     * It is generated automatically.
     */
    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private Long userId;

    /**
     * The email address of the user.
     */
    @NotBlank(message = "Email cannot be blank")
    @Email(message = "Email should be valid")
    private String email;

    /**
     * The password of the user.
     */
    @NotBlank(message = "Password cannot be blank")
    @Size(min = 8, message = "Password should have at least 8 characters")
    private String password;

    /**
     * The username of the user.
     */
   
    private String username;

    /**
     * The mobile number of the user.
     */
    private String mobileNumber;

    /**
     * The role of the user (e.g., admin, user).
     */
    
    private String role;

    /**
     * Default constructor for the User class.
     */
    public User() {
    }

    /**
     * Parameterized constructor for the User class.
     * 
     * @param userId The ID of the user.
     * @param email The email address of the user.
     * @param password The password of the user.
     * @param username The username of the user.
     * @param mobileNumber The mobile number of the user.
     * @param role The role of the user.
     */
    public User(Long userId, String email, String password, String username, String mobileNumber, String role) {
        this.userId = userId;
        this.email = email;
        this.password = password;
        this.username = username;
        this.mobileNumber = mobileNumber;
        this.role = role;
    }

    /**
     * Gets the ID of the user.
     * 
     * @return The ID of the user.
     */
    public Long getUserId() {
        return userId;
    }

    /**
     * Sets the ID of the user.
     * 
     * @param userId The new ID of the user.
     */
    public void setUserId(Long userId) {
        this.userId = userId;
    }

    /**
     * Gets the email address of the user.
     * 
     * @return The email address of the user.
     */
    public String getEmail() {
        return email;
    }

    /**
     * Sets the email address of the user.
     * 
     * @param email The new email address of the user.
     */
    public void setEmail(String email) {
        this.email = email;
    }

    /**
     * Gets the password of the user.
     * 
     * @return The password of the user.
     */
    public String getPassword() {
        return password;
    }

    /**
     * Sets the password of the user.
     * 
     * @param password The new password of the user.
     */
    public void setPassword(String password) {
        this.password = password;
    }

    /**
     * Gets the username of the user.
     * 
     * @return The username of the user.
     */
    public String getUsername() {
        return username;
    }

    /**
     * Sets the username of the user.
     * 
     * @param username The new username of the user.
     */
    public void setUsername(String username) {
        this.username = username;
    }

    /**
     * Gets the mobile number of the user.
     * 
     * @return The mobile number of the user.
     */
    public String getMobileNumber() {
        return mobileNumber;
    }

    /**
     * Sets the mobile number of the user.
     * 
     * @param mobileNumber The new mobile number of the user.
     */
    public void setMobileNumber(String mobileNumber) {
        this.mobileNumber = mobileNumber;
    }

    /**
     * Gets the role of the user.
     * 
     * @return The role of the user.
     */
    public String getRole() {
        return role;
    }

    /**
     * Sets the role of the user.
     * 
     * @param role The new role of the user.
     */
    public void setRole(String role) {
        this.role = role;
    }

    /**
     * Returns a string representation of the User object.
     * 
     * @return A string representation of the User object.
     */
    @Override
    public String toString() {
        return "User [userId=" + userId + ", email=" + email + ", password=" + password + ", username=" + username
                + ", mobileNumber=" + mobileNumber + ", role=" + role + "]";
    }
}
