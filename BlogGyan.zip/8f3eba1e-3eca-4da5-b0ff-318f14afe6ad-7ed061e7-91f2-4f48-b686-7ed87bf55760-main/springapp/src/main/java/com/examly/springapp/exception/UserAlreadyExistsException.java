package com.examly.springapp.exception;

/**
 * The UserAlreadyExistsException class is a custom exception
 * that is thrown when an attempt is made to create a user
 * that already exists.
 */
public class UserAlreadyExistsException extends Exception {

    /**
     * Default constructor for the UserAlreadyExistsException class.
     */
    public UserAlreadyExistsException() {
        super();
    }

    /**
     * Parameterized constructor for the UserAlreadyExistsException class.
     * 
     * @param message The error message associated with the exception.
     */
    public UserAlreadyExistsException(String message) {
        super(message);
    }
}
