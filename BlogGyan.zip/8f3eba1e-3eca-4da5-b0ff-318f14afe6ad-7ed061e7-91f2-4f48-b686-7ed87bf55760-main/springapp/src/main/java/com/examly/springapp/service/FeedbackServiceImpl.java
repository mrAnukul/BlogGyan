package com.examly.springapp.service;

import java.util.List;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import com.examly.springapp.exception.FeedbackNotFoundException;
import com.examly.springapp.exception.UserNotFoundException;
import com.examly.springapp.model.Feedback;
import com.examly.springapp.model.User;
import com.examly.springapp.repository.FeedbackRepo;
import com.examly.springapp.repository.UserRepo;

/**
 * The FeedbackServiceImpl class implements the FeedbackService interface
 * and provides the business logic for managing Feedback entities.
 */
@Service
public class FeedbackServiceImpl implements FeedbackService {

    private static final Logger logger = LoggerFactory.getLogger(FeedbackServiceImpl.class);

    @Autowired
    private FeedbackRepo feedbackRepo;

    @Autowired
    private UserRepo userRepo;

    @Value("${error.feedback.notfound}")
    private String errorMessageFeedbackNotFound;

    @Value("${error.feedback.user.notfound}")
    private String errorMessageUserNotFound;

    @Value("${logger.feedback.adding}")
    private String loggerMessageAdding;

    @Value("${logger.feedback.adding.notfound}")
    private String loggerMessageAddingNotFound;



    @Value("${logger.feedback.deleting.notfound}")
    private String loggerMessageDeletingNotFound;

    @Value("${logger.feedback.deleting}")
    private String loggerMessageDeleting;

    @Value("${logger.feedback.updating.notfound}")
    private String loggerMessageUpdatingNotFound;

    @Value("${logger.feedback.updating}")
    private String loggerMessageUpdating;

    @Value("${logger.feedback.fetching}")
    private String loggerMessageFetching;

    @Value("${logger.feedback.fetching.byuser}")
    private String loggerMessageFetchingByUser;

    @Value("${logger.feedback.user.notfound}")
    private String loggerMessageUserNotFound;
    @Value("${logger.feedback.warn}")
    private String loggerWarn;

    /**
     * Adds a new feedback.
     * 
     * @param feedback The feedback to be added.
     * @return The added feedback.
     * @throws UserNotFoundException if the user associated with the feedback is not found.
     */
    @Override
    public Feedback addFeedback(Feedback feedback) throws UserNotFoundException {
        User foundUser = feedback.getUser();
        User user = userRepo.findById(foundUser.getUserId()).orElse(null);
        if (user == null) {
            logger.error(loggerMessageAddingNotFound, foundUser.getUserId());
            throw new UserNotFoundException(errorMessageUserNotFound);
        }
        logger.info(loggerMessageAdding, foundUser.getUserId());
        return feedbackRepo.save(feedback);
    }

    /**
     * Retrieves all feedbacks.
     * 
     * @return A list of all feedbacks.
     */
    @Override
    public List<Feedback> getAllFeedback() {
        logger.debug(loggerMessageFetching);
        return feedbackRepo.findAll();
    }

    /**
     * Retrieves all feedbacks by the user ID.
     * 
     * @param userId The ID of the user.
     * @return A list of feedbacks provided by the specified user.
     * @throws UserNotFoundException if the user with the specified ID is not found.
     */
    @Override
    public List<Feedback> getAllFeedbackByUserId(Long userId) throws UserNotFoundException {
        User foundUser = userRepo.findById(userId).orElse(null);
        if (foundUser == null) {
            logger.error(loggerMessageUserNotFound, userId);
            throw new UserNotFoundException(errorMessageUserNotFound);
        }
        logger.info(loggerMessageFetchingByUser, userId);
        return feedbackRepo.findFeedbacksByUserId(userId);
    }

    /**
     * Edits an existing feedback.
     * 
     * @param feedbackId The ID of the feedback to be edited.
     * @param updatedFeedback The updated feedback details.
     * @return The updated feedback.
     * @throws FeedbackNotFoundException if the feedback with the specified ID is not found.
     */
    @Override
    public Feedback editFeedback(Long feedbackId, Feedback updatedFeedback) throws FeedbackNotFoundException {
        if (feedbackId == null) {
            logger.warn(loggerWarn);
            return null;
        }
        Feedback foundFeedback = feedbackRepo.findById(feedbackId).orElse(null);
        if (foundFeedback == null) {
            logger.error(loggerMessageUpdatingNotFound, feedbackId);
            throw new FeedbackNotFoundException(errorMessageFeedbackNotFound);
        }
        updatedFeedback.setFeedbackId(foundFeedback.getFeedbackId());
        updatedFeedback.setUser(foundFeedback.getUser());
        logger.info(loggerMessageUpdating, feedbackId);
        return feedbackRepo.save(updatedFeedback);
    }

    /**
     * Deletes an existing feedback.
     * 
     * @param feedbackId The ID of the feedback to be deleted.
     * @return The deleted feedback.
     * @throws FeedbackNotFoundException if the feedback with the specified ID is not found.
     */
    @Override
    public Feedback deleteFeedback(Long feedbackId) throws FeedbackNotFoundException {
        Feedback foundFeedback = feedbackRepo.findById(feedbackId).orElse(null);
        if (foundFeedback != null) {
            feedbackRepo.delete(foundFeedback);
            logger.info(loggerMessageDeleting, feedbackId);
            return foundFeedback;
        }
        logger.error(loggerMessageDeletingNotFound, feedbackId);
        throw new FeedbackNotFoundException(errorMessageFeedbackNotFound);
    }
}
