package com.examly.springapp.service;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import com.examly.springapp.exception.BlogPostNotFoundException;
import com.examly.springapp.exception.UserNotFoundException;
import com.examly.springapp.model.BlogPost;
import com.examly.springapp.model.User;
import com.examly.springapp.repository.BlogPostRepo;
import com.examly.springapp.repository.UserRepo;

/**
 * The BlogPostServiceImpl class implements the BlogPostService interface
 * and provides the business logic for managing BlogPost entities.
 */
@Service
public class BlogPostServiceImpl implements BlogPostService {
    private static final Logger logger = LoggerFactory.getLogger(BlogPostServiceImpl.class);

    @Autowired
    private BlogPostRepo blogPostRepo;

    @Autowired
    private UserRepo userRepo;

    @Value("${error.blogpost.notfound}")
    private String errorMessageBlogPostNotFound;

    @Value("${error.user.notfound}")
    private String errorMessageUserNotFound;

    @Value("${logger.blogpost.adding}")
    private String loggerMessageAdding;

    @Value("${logger.blogpost.deleting.notfound}")
    private String loggerMessageDeletingNotFound;

    @Value("${logger.blogpost.deleting}")
    private String loggerMessageDeleting;

    @Value("${logger.blogpost.updating.notfound}")
    private String loggerMessageUpdatingNotFound;

    @Value("${logger.blogpost.updating}")
    private String loggerMessageUpdating;

    @Value("${logger.blogpost.fetching}")
    private String loggerMessageFetching;

    @Value("${logger.blogpost.fetching.byuser}")
    private String loggerMessageFetchingByUser;

    @Value("${logger.blogpost.fetching.byid}")
    private String loggerMessageFetchingById;

    /**
     * Adds a new blog post.
     * 
     * @param blogPost The blog post to be added.
     * @return The added blog post.
     * @throws UserNotFoundException if the user associated with the blog post is not found.
     */
    @Override
    public BlogPost addBlogPost(BlogPost blogPost) throws UserNotFoundException {
        User foundUser = blogPost.getUser();
        User user = userRepo.findById(foundUser.getUserId()).orElse(null);
        if (user == null) {
            logger.error(loggerMessageDeletingNotFound, foundUser.getUserId());
            throw new UserNotFoundException(errorMessageUserNotFound);
        }
        logger.info(loggerMessageAdding, foundUser.getUserId());
        return blogPostRepo.save(blogPost);
    }

    /**
     * Deletes an existing blog post.
     * 
     * @param blogPostId The ID of the blog post to be deleted.
     * @return The deleted blog post.
     * @throws BlogPostNotFoundException if the blog post with the specified ID is not found.
     */
    @Override
    public BlogPost deleteBlogPost(Long blogPostId) throws BlogPostNotFoundException {
        BlogPost deletedBlogPost = blogPostRepo.findById(blogPostId).orElse(null);
        if (deletedBlogPost == null) {
            logger.error(loggerMessageDeletingNotFound, blogPostId);
            throw new BlogPostNotFoundException(errorMessageBlogPostNotFound);
        }
        blogPostRepo.delete(deletedBlogPost);
        logger.info(loggerMessageDeleting, blogPostId);
        return deletedBlogPost;
    }

    /**
     * Edits an existing blog post.
     * 
     * @param blogPostId The ID of the blog post to be edited.
     * @param updatedBlogPost The updated blog post details.
     * @return The updated blog post.
     * @throws BlogPostNotFoundException if the blog post with the specified ID is not found.
     */
    @Override
    public BlogPost editBlogPost(Long blogPostId, BlogPost updatedBlogPost) throws BlogPostNotFoundException {
        BlogPost foundedBlogPost = blogPostRepo.findById(blogPostId).orElse(null);
        if (foundedBlogPost == null) {
            logger.error(loggerMessageUpdatingNotFound, blogPostId);
            throw new BlogPostNotFoundException(errorMessageBlogPostNotFound);
        }
        updatedBlogPost.setBlogPostId(blogPostId);
        logger.info(loggerMessageUpdating, blogPostId);
        return blogPostRepo.save(updatedBlogPost);
    }

    /**
     * Retrieves all blog posts.
     * 
     * @return A list of all blog posts.
     */
    @Override
    public List<BlogPost> getAllBlogPosts() {
        logger.debug(loggerMessageFetching);
        return blogPostRepo.findAll();
    }

    /**
     * Retrieves all blog posts by the user ID.
     * 
     * @param userId The ID of the user.
     * @return A list of blog posts created by the specified user.
     * @throws UserNotFoundException if the user with the specified ID is not found.
     */
    @Override
    public List<BlogPost> getAllBlogPostsByUserId(Long userId) throws UserNotFoundException {
        User foundUser = userRepo.findById(userId).orElse(null);
        if (foundUser == null) {
            logger.error(loggerMessageDeletingNotFound, userId);
            throw new UserNotFoundException(errorMessageUserNotFound);
        }
        logger.info(loggerMessageFetchingByUser, userId);
        return blogPostRepo.findBlogPostsByUserId(userId);
    }

    /**
     * Retrieves a blog post by its ID.
     * 
     * @param blogPostId The ID of the blog post to be retrieved.
     * @return The blog post with the specified ID.
     * @throws BlogPostNotFoundException if the blog post with the specified ID is not found.
     */
    @Override
    public BlogPost getBlogPostById(Long blogPostId) throws BlogPostNotFoundException {
        BlogPost foundedBlogPost = blogPostRepo.findById(blogPostId).orElse(null);
        if (foundedBlogPost == null) {
            logger.error(loggerMessageFetchingById, blogPostId);
            throw new BlogPostNotFoundException(errorMessageBlogPostNotFound + blogPostId);
        }
        logger.info(loggerMessageFetchingById, blogPostId);
        return foundedBlogPost;
    }
    @Override
    public BlogPost likePost(Long postId) {
        BlogPost post = blogPostRepo.findById(postId).orElseThrow(() -> new RuntimeException("Post not found"));
        post.setLikes(post.getLikes() + 1);
        return blogPostRepo.save(post);
    }
}
