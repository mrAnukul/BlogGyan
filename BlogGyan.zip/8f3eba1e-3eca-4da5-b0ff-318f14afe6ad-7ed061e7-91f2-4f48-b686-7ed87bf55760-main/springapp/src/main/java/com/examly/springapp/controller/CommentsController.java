package com.examly.springapp.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

import com.examly.springapp.exception.CommentNotFoundException;
import com.examly.springapp.model.BlogPost;
import com.examly.springapp.model.Comment;
import com.examly.springapp.service.CommentService;

import java.util.List;

/**
 * The CommentsController class handles HTTP requests for managing comments.
 * It provides endpoints for creating, retrieving, updating, and deleting comments.
 */
@RestController
@RequestMapping("/api/comments")
public class CommentsController {

    @Autowired
    private CommentService commentService;

    /**
     * Adds a new comment.
     * 
     * @param comment The comment to be added.
     * @return The added comment with HTTP status CREATED.
     */
    @PreAuthorize("hasAuthority('USER')")
    @PostMapping
    public ResponseEntity<Comment> addComment(@RequestBody Comment comment) {
        Comment newComment = commentService.addComment(comment);
        return ResponseEntity.status(HttpStatus.CREATED).body(newComment);
    }

    /**
     * Retrieves all comments for a blog post.
     * 
     * @param blogPost The blog post whose comments are to be retrieved.
     * @return A list of comments for the specified blog post with HTTP status OK.
     * @throws CommentNotFoundException if no comments are found for the specified blog post.
     */
    @GetMapping("/blogPost/{blogPostId}")
    public ResponseEntity<List<Comment>> getCommentsByBlogPostId(@PathVariable Long blogPostId) throws CommentNotFoundException {
        List<Comment> comments = commentService.getCommentsByBlogPostId(blogPostId);
        return ResponseEntity.status(HttpStatus.OK).body(comments);
    }

    /**
     * Deletes an existing comment.
     * 
     * @param commentId The ID of the comment to be deleted.
     * @return A message indicating the result of the delete operation with HTTP status NO_CONTENT.
     * @throws CommentNotFoundException if the comment with the specified ID is not found.
     */
    @PreAuthorize("hasAuthority('USER')")
    @DeleteMapping("/delete/{commentId}")
    public ResponseEntity<String> deleteComment(@PathVariable Long commentId) throws CommentNotFoundException {
        boolean isDeleted = commentService.deleteComment(commentId);
        if (isDeleted) {
            return ResponseEntity.status(HttpStatus.NO_CONTENT).body("Comment deleted successfully.");
        } else {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body("Failed to delete the comment.");
        }
    }
}
