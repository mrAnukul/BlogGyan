package com.examly.springapp.model;

import java.time.LocalDate;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.PastOrPresent;
import jakarta.validation.constraints.Size;

/**
 * The BlogPost class represents a blog post entity.
 * It is annotated with @Entity to map the class to a database table.
 */
@Entity
public class BlogPost {

    /**
     * blogPostId is a primary key.
     * It is generated automatically.
     */
    @Id
    @GeneratedValue(strategy=GenerationType.AUTO)
    private Long blogPostId;

    /**
     * The title of the blog post.
     */
    @NotBlank(message = "Title cannot be blank")
    @Size(min = 5, max = 100, message = "Title should be between 5 and 100 characters")
    private String title;

    /**
     * The content of the blog post.
     */
    @NotBlank(message = "Content cannot be blank")
    @Size(min = 10, message = "Content should have at least 10 characters")
    @Column(length=1000)
    private String content;

    /**
     * The date when the blog post was published.
     * It is initialized to the current date.
     */
    @NotNull(message = "Published date cannot be null")
    @PastOrPresent(message = "Published date cannot be in the future")
    private LocalDate publishedDate = LocalDate.now();

    /**
     * The status of the blog post (e.g., Active, Inactive).
     */
    // @NotBlank(message = "Status cannot be blank")
    private String status;
    private int likes;
    /**
     * The user who created the blog post.
     * It is a many-to-one relationship.
     * Many blogposts belong to one user.
     */
    @ManyToOne
    @JoinColumn(name="user_id")
    @NotNull(message = "User cannot be null")
    private User user;

    /**
     * Default constructor for the BlogPost class.
     */
    public BlogPost() {
    }

    /**
     * Parameterized constructor for the BlogPost class.
     * 
     * @param blogPostId The ID of the blog post.
     * @param title The title of the blog post.
     * @param content The content of the blog post.
     * @param publishedDate The date when the blog post was published.
     * @param status The status of the blog post.
     * @param user The user who created the blog post.
     */
    public BlogPost(Long blogPostId, String title, String content, LocalDate publishedDate, String status, User user) {
        this.blogPostId = blogPostId;
        this.title = title;
        this.content = content;
        this.publishedDate = publishedDate;
        this.status = status;
        this.user = user;
    }

    /**
     * Gets the ID of the blog post.
     * 
     * @return The ID of the blog post.
     */
    public Long getBlogPostId() {
        return blogPostId;
    }

    /**
     * Sets the ID of the blog post.
     * 
     * @param blogPostId The new ID of the blog post.
     */
    public void setBlogPostId(Long blogPostId) {
        this.blogPostId = blogPostId;
    }

    /**
     * Gets the title of the blog post.
     * 
     * @return The title of the blog post.
     */
    public String getTitle() {
        return title;
    }

    /**
     * Sets the title of the blog post.
     * 
     * @param title The new title of the blog post.
     */
    public void setTitle(String title) {
        this.title = title;
    }

    /**
     * Gets the content of the blog post.
     * 
     * @return The content of the blog post.
     */
    public String getContent() {
        return content;
    }

    /**
     * Sets the content of the blog post.
     * 
     * @param content The new content of the blog post.
     */
    public void setContent(String content) {
        this.content = content;
    }

    /**
     * Gets the published date of the blog post.
     * 
     * @return The published date of the blog post.
     */
    public LocalDate getPublishedDate() {
        return publishedDate;
    }

    /**
     * Sets the published date of the blog post.
     * 
     * @param publishedDate The new published date of the blog post.
     */
    public void setPublishedDate(LocalDate publishedDate) {
        this.publishedDate = publishedDate;
    }

    /**
     * Gets the status of the blog post.
     * 
     * @return The status of the blog post.
     */
    public String getStatus() {
        return status;
    }

    /**
     * Sets the status of the blog post.
     * 
     * @param status The new status of the blog post.
     */
    public void setStatus(String status) {
        this.status = status;
    }

    /**
     * Gets the user who created the blog post.
     * 
     * @return The user who created the blog post.
     */
    public User getUser() {
        return user;
    }

    /**
     * Sets the user who created the blog post.
     * 
     * @param user The new user who created the blog post.
     */
    public void setUser(User user) {
        this.user = user;
    }

    /**
     * Returns a string representation of the BlogPost object.
     * 
     * @return A string representation of the BlogPost object.
     */
    @Override
    public String toString() {
        return "BlogPost [blogPostId=" + blogPostId + ", title=" + title + ", content=" + content + ", publishedDate="
                + publishedDate + ", status=" + status + ", user=" + user + "]";
    }

    public int getLikes() {
        return likes;
    }

    public void setLikes(int likes) {
        this.likes = likes;
    }
}
