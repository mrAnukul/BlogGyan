package com.examly.springapp.repository;

import java.util.List;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;
import com.examly.springapp.model.BlogPost;

/**
 * The BlogPostRepo interface is a repository interface for managing BlogPost entities.
 * It extends JpaRepository to provide CRUD operations on BlogPost entities.
 * It also contains a custom query method to find blog posts by user ID.
 */
@Repository
public interface BlogPostRepo extends JpaRepository<BlogPost, Long> {

    /**
     * Finds blog posts by the user ID.
     * 
     * @param userId The ID of the user.
     * @return A list of blog posts created by the specified user.
     */
    @Query(value = "SELECT * FROM blog_post WHERE user_id = :userId", nativeQuery = true)
    List<BlogPost> findBlogPostsByUserId(Long userId);
}
