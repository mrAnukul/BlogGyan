package com.examly.springapp.service;

import java.util.List;

import com.examly.springapp.exception.UserAlreadyExistsException;
import com.examly.springapp.exception.UserNotFoundException;
import com.examly.springapp.model.LoginDTO;
import com.examly.springapp.model.User;

/**
 * The UserService interface defines the operations for managing User entities.
 * It provides methods to register and login users.
 */
public interface UserService {

    /**
     * Registers a new user.
     * 
     * @param user The user to be registered.
     * @return The registered user.
     * @throws UserAlreadyExistsException if a user with the same ID already exists.
     */
    User registerUser(User user) throws UserAlreadyExistsException;

    /**
     * Logs in an existing user.
     * 
     * @param user The user to be logged in.
     * @return The logged-in user.
     * @throws UserNotFoundException if the user with the specified credentials is not found.
     */
    LoginDTO loginUser(User user) throws UserNotFoundException;

    List<User> getAllUsers();
}
