package com.examly.springapp.service;

import java.util.List;
import com.examly.springapp.exception.BlogPostNotFoundException;
import com.examly.springapp.exception.UserNotFoundException;
import com.examly.springapp.model.BlogPost;

/**
 * The BlogPostService interface defines the operations for managing BlogPost entities.
 * It provides methods to add, retrieve, edit, and delete blog posts.
 */
public interface BlogPostService {

    /**
     * Adds a new blog post.
     * 
     * @param blogPost The blog post to be added.
     * @return The added blog post.
     * @throws UserNotFoundException if the user associated with the blog post is not found.
     */
    BlogPost addBlogPost(BlogPost blogPost) throws UserNotFoundException;

    /**
     * Retrieves all blog posts.
     * 
     * @return A list of all blog posts.
     */
    List<BlogPost> getAllBlogPosts();

    /**
     * Retrieves all blog posts by the user ID.
     * 
     * @param userId The ID of the user.
     * @return A list of blog posts created by the specified user.
     * @throws UserNotFoundException if the user with the specified ID is not found.
     */
    List<BlogPost> getAllBlogPostsByUserId(Long userId) throws UserNotFoundException;

    /**
     * Edits an existing blog post.
     * 
     * @param blogPostId The ID of the blog post to be edited.
     * @param updatedBlogPost The updated blog post details.
     * @return The updated blog post.
     * @throws BlogPostNotFoundException if the blog post with the specified ID is not found.
     */
    BlogPost editBlogPost(Long blogPostId, BlogPost updatedBlogPost) throws BlogPostNotFoundException;

    /**
     * Deletes an existing blog post.
     * 
     * @param blogPostId The ID of the blog post to be deleted.
     * @return The deleted blog post.
     * @throws BlogPostNotFoundException if the blog post with the specified ID is not found.
     */
    BlogPost deleteBlogPost(Long blogPostId) throws BlogPostNotFoundException;

    /**
     * Retrieves a blog post by its ID.
     * 
     * @param blogPostId The ID of the blog post to be retrieved.
     * @return The blog post with the specified ID.
     * @throws BlogPostNotFoundException if the blog post with the specified ID is not found.
     */
    BlogPost getBlogPostById(Long blogPostId) throws BlogPostNotFoundException;
    
    BlogPost likePost(Long postId);
}
