package com.examly.springapp.exception;

/**
 * The BlogPostNotFoundException class is a custom exception
 * that is thrown when an attempt is made to access a blog post
 * that is not found.
 */
public class BlogPostNotFoundException extends Exception {

    /**
     * Default constructor for the BlogPostNotFoundException class.
     */
    public BlogPostNotFoundException() {
        super();
    }

    /**
     * Parameterized constructor for the BlogPostNotFoundException class.
     * 
     * @param message The error message associated with the exception.
     */
    public BlogPostNotFoundException(String message) {
        super(message);
    }
}
