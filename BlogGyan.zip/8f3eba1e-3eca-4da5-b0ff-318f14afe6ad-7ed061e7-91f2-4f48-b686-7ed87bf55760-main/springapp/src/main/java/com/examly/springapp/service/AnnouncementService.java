package com.examly.springapp.service;

import java.util.List;
import com.examly.springapp.exception.AnnouncementAlreadyExistsException;
import com.examly.springapp.exception.AnnouncementNotFoundException;
import com.examly.springapp.model.Announcement;

/**
 * The AnnouncementService interface defines the operations for managing Announcement entities.
 * It provides methods to add, retrieve, edit, and delete announcements.
 */
public interface AnnouncementService {

    /**
     * Adds a new announcement.
     * 
     * @param announcement The announcement to be added.
     * @return The added announcement.
     * @throws AnnouncementAlreadyExistsException if an announcement with the same ID already exists.
     */
    Announcement addAnnouncement(Announcement announcement);

    /**
     * Retrieves all announcements.
     * 
     * @return A list of all announcements.
     * @throws AnnouncementNotFoundException if no announcements are found.
     */
    List<Announcement> getAllAnnouncements() throws AnnouncementNotFoundException;

    /**
     * Edits an existing announcement.
     * 
     * @param announcementId The ID of the announcement to be edited.
     * @param updatedAnnouncement The updated announcement details.
     * @return The updated announcement.
     * @throws AnnouncementNotFoundException if the announcement with the specified ID is not found.
     */
    Announcement editAnnouncement(Long announcementId, Announcement updatedAnnouncement) throws AnnouncementNotFoundException;

    /**
     * Deletes an existing announcement.
     * 
     * @param announcementId The ID of the announcement to be deleted.
     * @return The deleted announcement.
     * @throws AnnouncementNotFoundException if the announcement with the specified ID is not found.
     */
    Announcement deleteAnnouncement(Long announcementId) throws AnnouncementNotFoundException;

    /**
     * Retrieves an announcement by its ID.
     * 
     * @param announcementId The ID of the announcement to be retrieved.
     * @return The announcement with the specified ID.
     * @throws AnnouncementNotFoundException if the announcement with the specified ID is not found.
     */
    Announcement getByAnnouncementById(Long announcementId) throws AnnouncementNotFoundException;
}
