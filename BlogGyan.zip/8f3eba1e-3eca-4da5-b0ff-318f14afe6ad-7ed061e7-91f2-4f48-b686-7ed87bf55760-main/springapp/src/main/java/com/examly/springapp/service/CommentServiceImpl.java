package com.examly.springapp.service;

import java.util.List;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.examly.springapp.exception.CommentNotFoundException;
import com.examly.springapp.model.BlogPost;
import com.examly.springapp.model.Comment;
import com.examly.springapp.repository.BlogPostRepo;
import com.examly.springapp.repository.CommentRepo;

/**
 * The CommentServiceImpl class implements the CommentService interface
 * and provides the business logic for managing Comment entities.
 */
@Service
public class CommentServiceImpl implements CommentService {
    private static final Logger logger = LoggerFactory.getLogger(CommentServiceImpl.class);

    @Autowired
    private CommentRepo commentRepo;
    @Autowired
    private BlogPostRepo blogPostRepo;

    /**
     * Retrieves comments by blog post.
     *
     * @param blogPostId The ID of the blog post for which comments are to be fetched.
     * @return A list of comments for the specified blog post.
     * @throws CommentNotFoundException if no comments are found for the specified blog post.
     */
    @Override
    public List<Comment> getCommentsByBlogPostId(Long blogPostId) throws CommentNotFoundException {
        BlogPost blog = blogPostRepo.findById(blogPostId).orElse(null);
        if (blog == null) {
            throw new CommentNotFoundException("No comments found for blog post with ID: " + blogPostId);
        }
        List<Comment> comments = commentRepo.findCommentsByBlogPostId(blogPostId);
        if (comments.isEmpty()) {
            logger.error("No comments found for blog post with ID {}", blogPostId);
            throw new CommentNotFoundException("No comments found for blog post with ID: " + blogPostId);
        }
        return comments;
    }

    /**
     * Adds a new comment.
     *
     * @param comment The comment to be added.
     * @return The added comment.
     */
    @Override
    public Comment addComment(Comment comment) {
        logger.info("Adding new comment for blog post with ID {}", comment.getBlogPost().getBlogPostId());
        return commentRepo.save(comment);
    }

    /**
     * Deletes an existing comment by its ID.
     *
     * @param commentId The ID of the comment to be deleted.
     * @return true if the comment was deleted, false otherwise.
     * @throws CommentNotFoundException if the comment with the specified ID is not found.
     */
    @Override
    public boolean deleteComment(Long commentId) throws CommentNotFoundException {
        Comment commentToDelete = commentRepo.findById(commentId).orElse(null);
        if (commentToDelete == null) {
            logger.error("Comment with ID {} not found for deletion", commentId);
            throw new CommentNotFoundException("Comment with ID " + commentId + " not found for deletion");
        }
        commentRepo.delete(commentToDelete);
        logger.info("Deleted comment with ID {}", commentId);
        return true;
    }
}
