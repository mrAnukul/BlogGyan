package com.examly.springapp.exception;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;

/**
 * The GlobalExceptionHandler class handles exceptions globally across the application.
 * It uses the @ControllerAdvice annotation to handle exceptions thrown by controller methods.
 */
@ControllerAdvice
public class GlobalExceptionHandler {

    /**
     * Handles BlogPostNotFoundException and returns a 404 Not Found response.
     * 
     * @param e The exception to be handled.
     * @return A ResponseEntity containing the error message and HTTP status.
     */
    @ExceptionHandler(BlogPostNotFoundException.class)
    public ResponseEntity<String> handle(BlogPostNotFoundException e) {
        return ResponseEntity.status(HttpStatus.NOT_FOUND).body(e.getMessage());
    }

    /**
     * Handles AnnouncementAlreadyExistsException and returns a 409 Conflict response.
     * 
     * @param e The exception to be handled.
     * @return A ResponseEntity containing the error message and HTTP status.
     */
    @ExceptionHandler(AnnouncementAlreadyExistsException.class)
    public ResponseEntity<String> handle(AnnouncementAlreadyExistsException e) {
        return ResponseEntity.status(HttpStatus.CONFLICT).body(e.getMessage());
    }

    /**
     * Handles AnnouncementNotFoundException and returns a 404 Not Found response.
     * 
     * @param e The exception to be handled.
     * @return A ResponseEntity containing the error message and HTTP status.
     */
    @ExceptionHandler(AnnouncementNotFoundException.class)
    public ResponseEntity<String> handle(AnnouncementNotFoundException e) {
        return ResponseEntity.status(HttpStatus.NOT_FOUND).body(e.getMessage());
    }

    /**
     * Handles UserAlreadyExistsException and returns a 409 Conflict response.
     * 
     * @param e The exception to be handled.
     * @return A ResponseEntity containing the error message and HTTP status.
     */
    @ExceptionHandler(UserAlreadyExistsException.class)
    public ResponseEntity<String> handle(UserAlreadyExistsException e) {
        return ResponseEntity.status(HttpStatus.CONFLICT).body(e.getMessage());
    }

    /**
     * Handles UserNotFoundException and returns a 404 Not Found response.
     * 
     * @param e The exception to be handled.
     * @return A ResponseEntity containing the error message and HTTP status.
     */
    @ExceptionHandler(UserNotFoundException.class)
    public ResponseEntity<String> handle(UserNotFoundException e) {
        return ResponseEntity.status(HttpStatus.NOT_FOUND).body(e.getMessage());
    }

    /**
     * Handles FeedbackNotFoundException and returns a 404 Not Found response.
     * 
     * @param e The exception to be handled.
     * @return A ResponseEntity containing the error message and HTTP status.
     */
    @ExceptionHandler(FeedbackNotFoundException.class)
    public ResponseEntity<String> handle(FeedbackNotFoundException e) {
        return ResponseEntity.status(HttpStatus.NOT_FOUND).body(e.getMessage());
    }
}
