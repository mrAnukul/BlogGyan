package com.examly.springapp.exception;

/**
 * The UserNotFoundException class is a custom exception
 * that is thrown when an attempt is made to access a user
 * that is not found.
 */
public class UserNotFoundException extends Exception {

    /**
     * Default constructor for the UserNotFoundException class.
     */
    public UserNotFoundException() {
        super();
    }

    /**
     * Parameterized constructor for the UserNotFoundException class.
     * 
     * @param message The error message associated with the exception.
     */
    public UserNotFoundException(String message) {
        super(message);
    }
}
