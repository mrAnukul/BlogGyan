package com.examly.springapp.exception;

/**
 * The AnnouncementAlreadyExistsException class is a custom exception
 * that is thrown when an attempt is made to create an announcement 
 * that already exists.
 */
public class AnnouncementAlreadyExistsException extends RuntimeException {

    /**
     * Default constructor for the AnnouncementAlreadyExistsException class.
     */
    public AnnouncementAlreadyExistsException() {
        super();
    }

    /**
     * Parameterized constructor for the AnnouncementAlreadyExistsException class.
     * 
     * @param err The error message associated with the exception.
     */
    public AnnouncementAlreadyExistsException(String err) {
        super(err);
    }
}
