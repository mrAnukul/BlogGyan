package com.examly.springapp.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import com.examly.springapp.exception.UserAlreadyExistsException;
import com.examly.springapp.exception.UserNotFoundException;
import com.examly.springapp.model.LoginDTO;
import com.examly.springapp.model.User;
import com.examly.springapp.service.UserService;
import jakarta.validation.Valid;

/**
 * controller acts as intermediatory between the service logic and client
 * The AuthController class handles HTTP requests for user authentication and registration.
 * It provides endpoints for registering and logging in users.
 */
@RestController
// @CrossOrigin(origins = "https://ide-baacafdecfebfaabacacaebcaedeffbedbf.premiumproject.examly.io/proxy/8080")
@RequestMapping("/api")
public class AuthController {

    @Autowired
    private UserService userService; // assuming you have a UserService interface

    /**
     * Registers a new user.
     * 
     * @param user The user to be registered.
     * @return The registered user with HTTP status CREATED.
     * @throws UserAlreadyExistsException if a user with the same ID already exists.
     */
    @PostMapping("/register")
    public ResponseEntity<User> registerUser(@Valid @RequestBody User user) throws UserAlreadyExistsException {
        User registeredUser = userService.registerUser(user);
        return ResponseEntity.status(HttpStatus.CREATED).body(registeredUser);
    }

    /**
     * Logs in an existing user.
     * 
     * @param user The user to be logged in.
     * @return The logged-in user with HTTP status CREATED.
     * @throws UserNotFoundException if the user with the specified credentials is not found.
     */
    @PostMapping("/login")
    public ResponseEntity<LoginDTO> loginUser(@Valid @RequestBody User user) throws UserNotFoundException {
        LoginDTO registeredUser = userService.loginUser(user);
        return ResponseEntity.status(HttpStatus.CREATED).body(registeredUser);
    }
    @GetMapping("/users")
    public ResponseEntity<List<User>>getAllUsers(){
        List<User> users=userService.getAllUsers();
        return ResponseEntity.status(HttpStatus.OK).body(users);
    }

}
