package com.examly.springapp.controller;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

import com.examly.springapp.exception.AnnouncementAlreadyExistsException;
import com.examly.springapp.exception.AnnouncementNotFoundException;
import com.examly.springapp.model.Announcement;
import com.examly.springapp.service.AnnouncementService;
import jakarta.validation.Valid;

/**
 * controller acts as an intermediary between the service logic and client
 * The AnnouncementController class handles HTTP requests for managing announcements.
 * It provides endpoints for creating, retrieving, updating, and deleting announcements.
 */
@RestController
@RequestMapping("/api/announcements")
public class AnnouncementController {
    Logger logger=LoggerFactory.getLogger(AnnouncementController.class);
    @Autowired
    private AnnouncementService announcementService;

    /**
     * Creates a new announcement.
     * 
     * @param announcement The announcement to be created.
     * @return The created announcement with HTTP status CREATED.
     * @throws AnnouncementAlreadyExistsException if an announcement with the same ID already exists.
     */
    @PostMapping
    @PreAuthorize("hasAuthority('ADMIN')")
    public ResponseEntity<Announcement> createAnnouncement(@Valid @RequestBody Announcement announcement) {
        logger.info("CONTROLLER: {}", announcement);
        Announcement toAddannouncement = announcementService.addAnnouncement(announcement);
        return ResponseEntity.status(HttpStatus.CREATED).body(toAddannouncement);
    }

    /**
     * Retrieves all announcements.
     * 
     * @return A list of all announcements with HTTP status OK.
     * @throws AnnouncementNotFoundException if no announcements are found.
     */
    @GetMapping
    public ResponseEntity<List<Announcement>> getAllAnnouncements() throws AnnouncementNotFoundException {
        List<Announcement> allAnnouncements = announcementService.getAllAnnouncements();
        return ResponseEntity.status(HttpStatus.OK).body(allAnnouncements);
    }

    /**
     * Updates an existing announcement.
     * 
     * @param announcementId The ID of the announcement to be updated.
     * @param announcement   The updated announcement details.
     * @return The updated announcement with HTTP status OK.
     * @throws AnnouncementNotFoundException if the announcement with the specified ID is not found.
     */
    @PreAuthorize("hasAuthority('ADMIN')")
    @PutMapping("/{announcementId}")
    public ResponseEntity<Announcement> updateAnnouncement(@PathVariable Long announcementId, @Valid @RequestBody Announcement announcement) throws AnnouncementNotFoundException {
        Announcement updatedAnnouncement = announcementService.editAnnouncement(announcementId, announcement);
        return ResponseEntity.status(HttpStatus.OK).body(updatedAnnouncement);
    }

    /**
     * Deletes an existing announcement.
     * 
     * @param announcementId The ID of the announcement to be deleted.
     * @return An empty response with HTTP status NO_CONTENT.
     * @throws AnnouncementNotFoundException if the announcement with the specified ID is not found.
     */
    @PreAuthorize("hasAuthority('ADMIN')")
    @DeleteMapping("/{announcementId}")
    public ResponseEntity<Void> deleteAnnouncement(@PathVariable Long announcementId) throws AnnouncementNotFoundException {
        announcementService.deleteAnnouncement(announcementId);
        return ResponseEntity.status(HttpStatus.NO_CONTENT).build();
    }

    /**
     * Retrieves an announcement by its ID.
     * 
     * @param announcementId The ID of the announcement to be retrieved.
     * @return The announcement with the specified ID with HTTP status OK.
     * @throws AnnouncementNotFoundException if the announcement with the specified ID is not found.
     */
    @GetMapping("/{announcementId}")
    public ResponseEntity<Announcement> getAnnouncementById(@PathVariable Long announcementId) throws AnnouncementNotFoundException {
        Announcement getAnnouncementById = announcementService.getByAnnouncementById(announcementId);
        return ResponseEntity.status(HttpStatus.OK).body(getAnnouncementById);
    }
}
