package com.examly.springapp.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.examly.springapp.model.Announcement;

/**
 * The AnnouncementRepo interface is a repository interface for managing Announcement entities.
 * It extends JpaRepository to provide CRUD operations on Announcement entities.
 * It also contains a custom query method to find an Announcement by its ID and title.
 */
@Repository
public interface AnnouncementRepo extends JpaRepository<Announcement, Long> {

    
}
