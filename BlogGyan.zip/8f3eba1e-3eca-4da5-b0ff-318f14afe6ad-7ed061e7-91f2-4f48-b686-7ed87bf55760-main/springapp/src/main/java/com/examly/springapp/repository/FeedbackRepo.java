package com.examly.springapp.repository;

import java.util.List;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;
import com.examly.springapp.model.Feedback;

/**
 * The FeedbackRepo interface is a repository interface for managing Feedback entities.
 * It extends JpaRepository to provide CRUD operations on Feedback entities.
 * It also contains a custom query method to find feedbacks by user ID.
 */
@Repository
public interface FeedbackRepo extends JpaRepository<Feedback, Long> {

    /**
     * Finds feedbacks by the user ID.
     * 
     * @param userId The ID of the user.
     * @return A list of feedbacks provided by the specified user.
     */
    @Query(value = "SELECT * FROM feedback WHERE user_id = :userId", nativeQuery = true)
    List<Feedback> findFeedbacksByUserId(Long userId);
}
