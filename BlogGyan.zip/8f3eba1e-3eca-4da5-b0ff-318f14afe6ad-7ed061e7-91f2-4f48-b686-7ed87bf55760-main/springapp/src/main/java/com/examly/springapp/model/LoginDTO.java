package com.examly.springapp.model;

/**
 * The LoginDTO class is a Data Transfer Object (DTO) that represents the login information of a user.
 */
public class LoginDTO {

    /**
     * The ID of the user.
     */
    private Long userId;

    /**
     * The username of the user.
     */
    private String username;

    /**
     * The email address of the user.
     */
    private String email;

    /**
     * The JWT token for authentication.
     */
    private String jwtToken;

    /**
     * The role of the user (e.g., admin, user).
     */
    private String role;

    /**
     * Default constructor for the LoginDTO class.
     */
    public LoginDTO() {
    }

    /**
     * Parameterized constructor for the LoginDTO class.
     * 
     * @param userId The ID of the user.
     * @param username The username of the user.
     * @param email The email address of the user.
     * @param jwtToken The JWT token for authentication.
     * @param role The role of the user.
     */
    public LoginDTO(Long userId, String username, String email, String jwtToken, String role) {
        this.userId = userId;
        this.username = username;
        this.email = email;
        this.jwtToken = jwtToken;
        this.role = role;
    }

    /**
     * Gets the ID of the user.
     * 
     * @return The ID of the user.
     */
    public Long getUserId() {
        return userId;
    }

    /**
     * Sets the ID of the user.
     * 
     * @param userId The new ID of the user.
     */
    public void setUserId(Long userId) {
        this.userId = userId;
    }

    /**
     * Gets the username of the user.
     * 
     * @return The username of the user.
     */
    public String getUsername() {
        return username;
    }

    /**
     * Sets the username of the user.
     * 
     * @param username The new username of the user.
     */
    public void setUsername(String username) {
        this.username = username;
    }

    /**
     * Gets the email address of the user.
     * 
     * @return The email address of the user.
     */
    public String getEmail() {
        return email;
    }

    /**
     * Sets the email address of the user.
     * 
     * @param email The new email address of the user.
     */
    public void setEmail(String email) {
        this.email = email;
    }

    /**
     * Gets the JWT token for authentication.
     * 
     * @return The JWT token for authentication.
     */
    public String getJwtToken() {
        return jwtToken;
    }

    /**
     * Sets the JWT token for authentication.
     * 
     * @param jwtToken The new JWT token for authentication.
     */
    public void setJwtToken(String jwtToken) {
        this.jwtToken = jwtToken;
    }

    /**
     * Gets the role of the user.
     * 
     * @return The role of the user.
     */
    public String getRole() {
        return role;
    }

    /**
     * Sets the role of the user.
     * 
     * @param role The new role of the user.
     */
    public void setRole(String role) {
        this.role = role;
    }
}
