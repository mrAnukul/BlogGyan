package com.examly.springapp.model;

import java.time.LocalDate;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.PastOrPresent;
import jakarta.validation.constraints.Size;


/**
 * The Feedback class represents a feedback entity.
 * It is annotated with @Entity to map the class to a database table.
 */
@Entity
public class Feedback {

    /**
     * feedbackId is a primary key.
     * It is auto-generated.
     */
    @Id
    @GeneratedValue(strategy=GenerationType.AUTO)
    private Long feedbackId;

    /**
     * The text content of the feedback.
     */
    @NotBlank(message = "Feedback text cannot be blank")
    @Size(min = 1, message = "Feedback text should have at least 1 characters")
    private String feedbackText;

    /**
     * The date when the feedback was given.
     * It is initialized to the current date.
     */
    @NotNull(message = "Date cannot be null")
    @PastOrPresent(message = "Date cannot be in the future")
    private LocalDate date = LocalDate.now();

    /**
     * The user who provided the feedback.
     * It is a many-to-one relationship.
     * Many feedbacks belong to one user.
     */
    @ManyToOne
    @JoinColumn(name="user_id")
    @NotNull(message = "User cannot be null")
    private User user;

    /**
     * Default constructor for the Feedback class.
     */
    public Feedback() {

    }

    /**
     * Parameterized constructor for the Feedback class.
     * 
     * @param feedbackId The ID of the feedback.
     * @param feedbackText The text content of the feedback.
     * @param date The date when the feedback was given.
     * @param user The user who provided the feedback.
     */
    public Feedback(Long feedbackId, String feedbackText, LocalDate date, User user) {
        this.feedbackId = feedbackId;
        this.feedbackText = feedbackText;
        this.date = date;
        this.user = user;
    }

    /**
     * Gets the ID of the feedback.
     * 
     * @return The ID of the feedback.
     */
    public Long getFeedbackId() {
        return feedbackId;
    }

    /**
     * Sets the ID of the feedback.
     * 
     * @param feedbackId The new ID of the feedback.
     */
    public void setFeedbackId(Long feedbackId) {
        this.feedbackId = feedbackId;
    }

    /**
     * Gets the text content of the feedback.
     * 
     * @return The text content of the feedback.
     */
    public String getFeedbackText() {
        return feedbackText;
    }

    /**
     * Sets the text content of the feedback.
     * 
     * @param feedbackText The new text content of the feedback.
     */
    public void setFeedbackText(String feedbackText) {
        this.feedbackText = feedbackText;
    }

    /**
     * Gets the date when the feedback was given.
     * 
     * @return The date when the feedback was given.
     */
    public LocalDate getDate() {
        return date;
    }

    /**
     * Sets the date when the feedback was given.
     * 
     * @param date The new date when the feedback was given.
     */
    public void setDate(LocalDate date) {
        this.date = date;
    }

    /**
     * Gets the user who provided the feedback.
     * 
     * @return The user who provided the feedback.
     */
    public User getUser() {
        return user;
    }

    /**
     * Sets the user who provided the feedback.
     * 
     * @param user The new user who provided the feedback.
     */
    public void setUser(User user) {
        this.user = user;
    }

    /**
     * Returns a string representation of the Feedback object.
     * 
     * @return A string representation of the Feedback object.
     */
    @Override
    public String toString() {
        return "Feedback [feedbackId=" + feedbackId + ", feedbackText=" + feedbackText + ", date=" + date + ", user="
                + user + "]";
    }
}
