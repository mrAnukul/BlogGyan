package com.examly.springapp.configuration;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.context.annotation.Configuration;
import org.springframework.web.servlet.config.annotation.CorsRegistry;
import org.springframework.web.servlet.config.annotation.EnableWebMvc;
import org.springframework.web.servlet.config.annotation.WebMvcConfigurer;

@Configuration
@EnableWebMvc
public class CorsConfig implements WebMvcConfigurer {

    Logger logger = LoggerFactory.getLogger(CorsConfig.class);

    @Override
    public void addCorsMappings(CorsRegistry registry) {
        System.out.println("IN CORS CONFIG");
        logger.info("INSIDE CORS CONFIG");
        registry.addMapping("/**")
        .allowedOrigins("https://8081-baacafdecffebddccaacedeffbedbf.premiumproject.examly.io")
        //.allowedOriginPatterns("**")
        .allowedMethods("GET","POST","PUT","DELETE")
        .allowedHeaders("*")
        .allowCredentials(true);
    
    }
}
