package com.examly.springapp.model;

import java.time.LocalDate;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.PastOrPresent;
import jakarta.validation.constraints.Size;


/**
 * The Announcement class represents an announcement entity.
 * It is annotated with @Entity to map the class to a database table.
 */
@Entity
public class Announcement {

    /**
     * announcementId is a primary key.
     * It is generated automatically.
     */
    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private Long announcementId;

    /**
     * The title of the announcement.
     */
    @NotBlank(message = "Title cannot be blank")
    @Size(min = 5, max = 100, message = "Title should be between 5 and 100 characters")
    private String title;

    /**
     * The content of the announcement.
     */
    @NotBlank(message = "Content cannot be blank")
    @Size(min = 1, message = "Content should have at least 1 characters")
    private String content;

    /**
     * The status of the announcement (e.g., Active, Inactive).
     */
    @NotBlank(message = "Status cannot be blank")
    private String status;

    /**
     * The category of the announcement.
     */
    @NotBlank(message = "Category cannot be blank")
    private String category;

    /**
     * The priority of the announcement (e.g., High, Medium, Low).
     */
    @NotBlank(message = "Priority cannot be blank")
    private String priority;

    /**
     * The date when the announcement was published.
     * It is initialized to the current date.
     */
    @NotNull(message = "Published date cannot be null")
    @PastOrPresent(message = "Published date cannot be in the future")
    private LocalDate publishedDate = LocalDate.now();

    /**
     * Default constructor for the Announcement class.
     */
    public Announcement() {
    }

    /**
     * Parameterized constructor for the Announcement class.
     * 
     * @param announcementId The ID of the announcement.
     * @param title The title of the announcement.
     * @param content The content of the announcement.
     * @param status The status of the announcement.
     * @param category The category of the announcement.
     * @param priority The priority of the announcement.
     * @param publishedDate The date when the announcement was published.
     */
    public Announcement(Long announcementId, String title, String content, String status, String category, String priority, LocalDate publishedDate) {
        this.announcementId = announcementId;
        this.title = title;
        this.content = content;
        this.status = status;
        this.category = category;
        this.priority = priority;
        this.publishedDate = publishedDate;
    }

    /**
     * Gets the ID of the announcement.
     * 
     * @return The ID of the announcement.
     */
    public Long getAnnouncementId() {
        return announcementId;
    }

    /**
     * Sets the ID of the announcement.
     * 
     * @param announcementId The new ID of the announcement.
     */
    public void setAnnouncementId(Long announcementId) {
        this.announcementId = announcementId;
    }

    /**
     * Gets the title of the announcement.
     * 
     * @return The title of the announcement.
     */
    public String getTitle() {
        return title;
    }

    /**
     * Sets the title of the announcement.
     * 
     * @param title The new title of the announcement.
     */
    public void setTitle(String title) {
        this.title = title;
    }

    /**
     * Gets the content of the announcement.
     * 
     * @return The content of the announcement.
     */
    public String getContent() {
        return content;
    }

    /**
     * Sets the content of the announcement.
     * 
     * @param content The new content of the announcement.
     */
    public void setContent(String content) {
        this.content = content;
    }

    /**
     * Gets the status of the announcement.
     * 
     * @return The status of the announcement.
     */
    public String getStatus() {
        return status;
    }

    /**
     * Sets the status of the announcement.
     * 
     * @param status The new status of the announcement.
     */
    public void setStatus(String status) {
        this.status = status;
    }

    /**
     * Gets the category of the announcement.
     * 
     * @return The category of the announcement.
     */
    public String getCategory() {
        return category;
    }

    /**
     * Sets the category of the announcement.
     * 
     * @param category The new category of the announcement.
     */
    public void setCategory(String category) {
        this.category = category;
    }

    /**
     * Gets the priority of the announcement.
     * 
     * @return The priority of the announcement.
     */
    public String getPriority() {
        return priority;
    }

    /**
     * Sets the priority of the announcement.
     * 
     * @param priority The new priority of the announcement.
     */
    public void setPriority(String priority) {
        this.priority = priority;
    }

    /**
     * Gets the published date of the announcement.
     * 
     * @return The published date of the announcement.
     */
    public LocalDate getPublishedDate() {
        return publishedDate;
    }

    /**
     * Sets the published date of the announcement.
     * 
     * @param publishedDate The new published date of the announcement.
     */
    public void setPublishedDate(LocalDate publishedDate) {
        this.publishedDate = publishedDate;
    }

    /**
     * Returns a string representation of the Announcement object.
     * 
     * @return A string representation of the Announcement object.
     */
    @Override
    public String toString() {
        return "Announcement [announcementId=" + announcementId + ", title=" + title + ", content=" + content
                + ", status=" + status + ", category=" + category + ", priority=" + priority + ", publishedDate="
                + publishedDate + "]";
    }
}


// @NotBlank: Ensures that the field is not null and the trimmed length is greater than 0.

// @Size: Validates that the field's size is within the specified range.

// @NotNull: Ensures that the field is not null.

// @PastOrPresent: Ensures that the date is in the past or present, but not in the future