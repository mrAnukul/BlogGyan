package com.examly.springapp.controller;

import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

import com.examly.springapp.exception.BlogPostNotFoundException;
import com.examly.springapp.exception.UserNotFoundException;
import com.examly.springapp.model.BlogPost;
import com.examly.springapp.service.BlogPostService;
import jakarta.validation.Valid;

/**
 * controller acts as intermediatory between the service logic and client
 * The BlogPostController class handles HTTP requests for managing blog posts.
 * It provides endpoints for creating, retrieving, updating, and deleting blog posts.
 */
@RestController
@RequestMapping("/api/blogposts")
public class BlogPostController {

    @Autowired
    private BlogPostService blogPostService;

    /**
     * Adds a new blog post.
     * 
     * @param blogPost The blog post to be added.
     * @return The added blog post with HTTP status CREATED.
     * @throws UserNotFoundException if the user associated with the blog post is not found.
     */
    @PreAuthorize("hasAuthority('USER')")
    @PostMapping
    public ResponseEntity<BlogPost> addBlogPost(@Valid @RequestBody BlogPost blogPost) throws UserNotFoundException {
        BlogPost newBlogPost = blogPostService.addBlogPost(blogPost);
        return ResponseEntity.status(HttpStatus.CREATED).body(newBlogPost);
    }

    /**
     * Retrieves all blog posts.
     * 
     * @return A list of all blog posts with HTTP status OK.
     */
    @GetMapping
    public ResponseEntity<List<BlogPost>> getAllBlogPosts() {
        List<BlogPost> blogPostList = blogPostService.getAllBlogPosts();
        return ResponseEntity.status(HttpStatus.OK).body(blogPostList);
    }

    /**
     * Retrieves a blog post by its ID.
     * 
     * @param postId The ID of the blog post to be retrieved.
     * @return The blog post with the specified ID with HTTP status OK.
     * @throws BlogPostNotFoundException if the blog post with the specified ID is not found.
     */
    @GetMapping("/{postId}")
    public ResponseEntity<BlogPost> getBlogPostById(@PathVariable Long postId) throws BlogPostNotFoundException {
        BlogPost foundBlogPost = blogPostService.getBlogPostById(postId);
        return ResponseEntity.status(HttpStatus.OK).body(foundBlogPost);
    }

    /**
     * Updates an existing blog post.
     * 
     * @param postId The ID of the blog post to be updated.
     * @param blogPost The updated blog post details.
     * @return The updated blog post with HTTP status OK.
     * @throws BlogPostNotFoundException if the blog post with the specified ID is not found.
     */
    @PutMapping("/{postId}")
    public ResponseEntity<BlogPost> editBlogPost(@PathVariable Long postId, @Valid @RequestBody BlogPost blogPost) throws BlogPostNotFoundException {
        BlogPost updatedBlogPost = blogPostService.editBlogPost(postId, blogPost);
        return ResponseEntity.status(HttpStatus.OK).body(updatedBlogPost);
    }

    /**
     * Deletes an existing blog post.
     * 
     * @param postId The ID of the blog post to be deleted.
     * @return The deleted blog post with HTTP status NO_CONTENT.
     * @throws BlogPostNotFoundException if the blog post with the specified ID is not found.
     */
    @DeleteMapping("/{postId}")
    public ResponseEntity<BlogPost> deleteBlogPost(@PathVariable Long postId) throws BlogPostNotFoundException {
        BlogPost deletedBlogPost = blogPostService.deleteBlogPost(postId);
        return ResponseEntity.status(HttpStatus.NO_CONTENT).body(deletedBlogPost);
    }

    /**
     * Retrieves blog posts by user ID.
     * 
     * @param userId The ID of the user whose blog posts are to be retrieved.
     * @return A list of blog posts created by the specified user with HTTP status OK.
     * @throws UserNotFoundException if the user with the specified ID is not found.
     */
    @GetMapping("/user/{userId}")
    public ResponseEntity<List<BlogPost>> getBlogPostsByUserId(@PathVariable Long userId) throws UserNotFoundException {
        List<BlogPost> userBlogPosts = blogPostService.getAllBlogPostsByUserId(userId);
        return ResponseEntity.status(HttpStatus.OK).body(userBlogPosts);
    }
    @PreAuthorize("hasAuthority('USER')")
    @PostMapping("/{postId}/like")
    public ResponseEntity<BlogPost> likePost(@PathVariable Long postId) {
        BlogPost likedPost = blogPostService.likePost(postId);
        return new ResponseEntity<>(likedPost, HttpStatus.OK);
    }
}

