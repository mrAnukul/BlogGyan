package com.examly.springapp.service;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.crypto.password.PasswordEncoder;

import com.examly.springapp.configuration.JwtUtils;
import com.examly.springapp.exception.UserAlreadyExistsException;
import com.examly.springapp.exception.UserNotFoundException;
import com.examly.springapp.model.LoginDTO;
import com.examly.springapp.model.User;
import com.examly.springapp.repository.UserRepo;

/**
 * The UserServiceImpl class implements the UserService interface
 * and provides the business logic for managing User entities.
 */
@Service
public class UserServiceImpl implements UserService {

    private static final Logger logger = LoggerFactory.getLogger(UserServiceImpl.class);

    @Autowired
    private UserRepo userRepo;

    @Autowired
    private PasswordEncoder passwordEncoder;

    @Autowired
    private JwtUtils jwtUtils;

    @Autowired
    private UserDetailsService userDetailsService;

    @Value("${error.user.alreadyexists}")
    private String errorMessageUserAlreadyExists;

    @Value("${error.user.notfound}")
    private String errorMessageUserNotFound;

    @Value("${logger.user.registering}")
    private String loggerMessageRegistering;

    @Value("${logger.user.loggingin}")
    private String loggerMessageLoggingIn;

    @Value("${logger.user.fetching}")
    private String loggerMessageFetching;

    /**
     * Registers a new user.
     * 
     * @param user The user to be registered.
     * @return The registered user.
     * @throws UserAlreadyExistsException if a user with the same ID already exists.
     */
    @Override
    public User registerUser(User user) throws UserAlreadyExistsException {
        String userEmail = user.getEmail();
        User foundedUser = userRepo.findByEmail(userEmail);
        if (foundedUser == null) {
            user.setPassword(passwordEncoder.encode(user.getPassword()));
            user.setRole(user.getRole().toUpperCase());
            return userRepo.save(user);
        }
        logger.error(loggerMessageRegistering, userEmail);
        throw new UserAlreadyExistsException(errorMessageUserAlreadyExists + userEmail);
    }

    /**
     * Logs in an existing user.
     * 
     * @param user The user to be logged in.
     * @return The logged-in user.
     * @throws UserNotFoundException if the user with the specified credentials is
     *                               not found.
     */
    @Override
    public LoginDTO loginUser(User user) throws UserNotFoundException {
        logger.info("AUTH SERVICE: {}", user);
        User existedUser = userRepo.findByEmail(user.getEmail());
        if (existedUser != null) {
            UserDetails userDetails = userDetailsService.loadUserByUsername(user.getEmail());
            if (passwordEncoder.matches(user.getPassword(), userDetails.getPassword())) {
                return new LoginDTO(existedUser.getUserId(), existedUser.getUsername(), existedUser.getEmail(),
                        jwtUtils.generateToken(existedUser.getEmail()), existedUser.getRole().toUpperCase());
            }
        }
        logger.error(loggerMessageLoggingIn, user.getEmail());
        throw new UserNotFoundException(errorMessageUserNotFound + user.getEmail());
    }

    @Override
    public List<User> getAllUsers() {
        logger.debug(loggerMessageFetching);
        return userRepo.findAll();
    }
}
