export const apiUrl="https://8080-baacafdecffebddccaacedeffbedbf.premiumproject.examly.io/api";

