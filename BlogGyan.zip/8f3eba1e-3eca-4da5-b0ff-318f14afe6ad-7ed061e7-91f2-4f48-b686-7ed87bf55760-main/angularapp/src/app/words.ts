export const ABUSIVE_WORDS: string[] = [
    'idiot', 'fool', 'moron', 'stupid', 'dumb', 'jerk', 'loser', 'clown', 'suck', 
    'crap', 'garbage', 'trash', 'nonsense', 'pathetic', 'worthless', 'useless', 
    'disgusting', 'annoying', 'hate', 'terrible', 'horrible', 'awful', 'ugly', 
    'gross', 'dirty', 'insane', 'crazy', 'maniac', 'psycho', 'freak', 'wacko', 
    'lame', 'silly', 'obnoxious', 'nasty', 'vulgar', 'offensive', 'repulsive', 
    'naughty', 'insult', 'harass', 'bully', 'troll', 'spam', 'curse', 'swear', 
    'profanity', 'cuss', 'bitch', 'bastard','fuck','shit'
  ];
  