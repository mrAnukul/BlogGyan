
export interface Announcement {
    announcementId?:number;
    title?:string;
    content?:string;
    status?:string;
    category?:string;
    priority?:string;
    publishedDate?:string;
}
