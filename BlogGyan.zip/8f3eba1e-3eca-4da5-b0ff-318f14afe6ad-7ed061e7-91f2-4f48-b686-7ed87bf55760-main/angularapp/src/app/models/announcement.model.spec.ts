import { Announcement } from './announcement.model';

describe('Announcement Model', () => {

  fit('frontend_announcement model should create an instance', () => {
    // Create a sample user object
    const announcement: Announcement = {
        status :'Active'
    };

    expect(announcement).toBeTruthy();
    expect(announcement.status).toBe('Active');

  });
});
