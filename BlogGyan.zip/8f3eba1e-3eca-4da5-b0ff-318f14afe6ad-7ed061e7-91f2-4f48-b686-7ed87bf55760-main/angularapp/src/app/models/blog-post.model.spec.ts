import { BlogPost } from './blog-post.model';

describe('BlogPost Model', () => {

  fit('frontend_blogPost model should create an instance', () => {
    // Create a sample user object
    const blogPost: BlogPost = {
        title : "Sample"
    };

    expect(blogPost).toBeTruthy();
    expect(blogPost.title).toBe("Sample");

  });
});
