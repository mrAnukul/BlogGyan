export interface Login {
    userId?:number;
    username?:string;
    email?:string;
    jwtToken?:string;
    role?:string;
}
