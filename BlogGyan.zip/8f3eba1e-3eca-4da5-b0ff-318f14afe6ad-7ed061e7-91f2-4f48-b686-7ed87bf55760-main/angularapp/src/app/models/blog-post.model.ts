import { User } from "./user.model";

export interface BlogPost {
    blogPostId?:number;
    title?:string;
    content?:string;
    publishedDate?:string;
    status?:string;
    user?:User;
    showMore?:boolean;
    likes?:number;
}
