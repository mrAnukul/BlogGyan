import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { User } from '../models/user.model';
import { Observable } from 'rxjs';
import { apiUrl } from '../constants';
import { Login } from '../models/login.model';
import { Router } from '@angular/router';

@Injectable({
  providedIn: 'root'
})
export class AuthService {

  constructor(private readonly http: HttpClient, private readonly router: Router) { }

  register(user: User): Observable<any> {
    return this.http.post<User>(apiUrl + "/register", user);
  }

  login(login: User): Observable<any> {
    return this.http.post<User>(apiUrl + "/login", login);
  }

  isLoggedIn(): boolean {
    return this.getAuthUser() !== null;
  }
  getUserRole(): string | null {
    const authUser = this.getAuthUser();
    return authUser ? authUser.role : null;
  }

  isUser(): boolean {
    const authUser = this.getAuthUser();
    return authUser && authUser.role === 'USER';
  }

  isAdmin(): boolean {
    const authUser = this.getAuthUser();
    return authUser && authUser.role === 'ADMIN';
  }

  logout() {
    sessionStorage.clear(); // This will clear all localStorage items
    this.router.navigate(['/login']); // Navigate to the login page or any other page you wish to redirect after logout
  }

  getAllUsers(): Observable<any> {
    return this.http.get<User[]>(apiUrl + "/users");
  }

  getToken() {
    return this.getAuthUser() ? this.getAuthUser().jwtToken : null;
  }

  setAuthUser(authUser: Login) {
    sessionStorage.setItem("AUTHUSER", JSON.stringify(authUser));
  }

  getUserName() {
    return this.getAuthUser() ? this.getAuthUser().username : null;
  }

  getAuthUser() {
    const str = sessionStorage.getItem("AUTHUSER");
    return str ? JSON.parse(str) : null;
  }
}
