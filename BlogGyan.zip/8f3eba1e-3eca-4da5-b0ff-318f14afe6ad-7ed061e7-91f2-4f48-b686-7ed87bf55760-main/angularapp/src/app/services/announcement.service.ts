import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Announcement } from '../models/announcement.model';
import { Observable } from 'rxjs';
import { apiUrl } from '../constants';
@Injectable({
  providedIn: 'root'
})
export class AnnouncementService {

  constructor(public http: HttpClient) { }
  getAllAnnouncements():Observable<Announcement[]>{
    return this.http.get<Announcement[]>(apiUrl+"/announcements");
  }
  getAnnouncementById(id:number):Observable<Announcement>{
    return this.http.get<Announcement>(apiUrl+"/announcements/"+id);
  }
  addAnnouncement(announcement:Announcement):Observable<any>{
    return this.http.post<Announcement>(apiUrl+"/announcements",announcement);
  }
  updateAnnouncement(id:number,announcement:Announcement):Observable<any>{
    return this.http.put<Announcement>(apiUrl+"/announcements/"+id,announcement);
  }
  deleteAnnouncement(id:number):Observable<any>{
    return this.http.delete<void>(apiUrl+"/announcements/"+id);
  }
}
