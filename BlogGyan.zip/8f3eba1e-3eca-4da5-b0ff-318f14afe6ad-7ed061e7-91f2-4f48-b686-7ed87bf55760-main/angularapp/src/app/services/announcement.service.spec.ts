import { TestBed } from '@angular/core/testing';

import { AnnouncementService } from './announcement.service';
import { HttpClientTestingModule } from '@angular/common/http/testing';

describe('AnnouncementService', () => {
  let service: AnnouncementService;

  beforeEach(() => {
    TestBed.configureTestingModule({
      imports: [HttpClientTestingModule],
    });
    service = TestBed.inject(AnnouncementService);
  });

  fit('frontend_announcement service should be created', () => {
    expect(service).toBeTruthy();
  });
});
