import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Feedback } from '../models/feedback.model';
import { Observable } from 'rxjs';
import { apiUrl } from '../constants';

@Injectable({
  providedIn: 'root'
})
export class FeedbackService {

  constructor(private readonly http:HttpClient) { }

  sendFeedBack(feedback:Feedback):Observable<any>{
    return this.http.post<Feedback>(apiUrl+"/feedback",feedback)
  }

  getAllFeedbacksByUserId(userId:number):Observable<Feedback[]>{
    return this.http.get<Feedback[]>(apiUrl+"/feedback/user/"+userId)
  }

  deleteFeedback(feedbackId:number):Observable<any>{
    return this.http.delete<void>(apiUrl+"/feedback/delete/"+feedbackId)
  }

  getFeedbacks():Observable<Feedback[]>{
    return this.http.get<Feedback[]>(apiUrl+"/feedback")
  }

  editFeedback(feedbackId: string, feedback: Feedback): Observable<Feedback> {
    return this.http.put<Feedback>(apiUrl +"/feedback/edit/"+feedbackId, feedback);
  }

}
