import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { Comment } from '../models/comment.model';
import { apiUrl } from '../constants';

@Injectable({
  providedIn: 'root'
})
export class CommentService {

  constructor(private readonly http: HttpClient) { }

  getCommentsByBlogPostId(blogPostId: number): Observable<Comment[]> {
    return this.http.get<Comment[]>(`${apiUrl}/comments/blogPost/${blogPostId}`);
  }

  addComment(comment: Comment): Observable<Comment> {
    return this.http.post<Comment>(`${apiUrl}/comments`, comment);
  }

  deleteComment(commentId: number): Observable<void> {
    return this.http.delete<void>(`${apiUrl}/comments/delete/${commentId}`);
  }
}