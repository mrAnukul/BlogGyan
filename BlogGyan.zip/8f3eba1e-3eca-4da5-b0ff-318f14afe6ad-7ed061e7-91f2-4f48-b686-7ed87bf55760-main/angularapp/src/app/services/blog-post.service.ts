import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { BlogPost } from '../models/blog-post.model';
import { Observable } from 'rxjs';
import { apiUrl } from '../constants';

@Injectable({
  providedIn: 'root'
})
export class BlogPostService {

  constructor(private readonly http:HttpClient) { }
  getAllBlogPosts():Observable<BlogPost[]>{
    return this.http.get<BlogPost[]>(apiUrl+"/blogposts");
  }
  getBlogPostByUserId(id:number):Observable<BlogPost[]>{
    return this.http.get<BlogPost[]>(apiUrl+"/blogposts/user/"+id)
  }
  addBlogPost(blogPost:BlogPost):Observable<any>{
    console.log("I am here",blogPost);
    return this.http.post<BlogPost>(apiUrl+"/blogposts",blogPost);
  }
  updateBlogPost(blogPost:BlogPost):Observable<any>{
    return this.http.put<BlogPost>(apiUrl+"/blogposts/"+blogPost.blogPostId,blogPost);
  }
  deleteBlogPost(id:number):Observable<any>{
    return this.http.delete<void>(apiUrl+"/blogposts/"+id)
  }
  getBlogPostByPostId(id:number):Observable<BlogPost>{
    return this.http.get<BlogPost>(apiUrl+"/blogposts/"+id);
  }
  likePost(postId: number): Observable<any> {
    return this.http.post(apiUrl+"/blogposts/" + postId + '/like', {});
  }
}
