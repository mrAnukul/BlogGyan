import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { LoggerService } from 'src/app/logger.service';
import { LOGGING_MESSAGES } from 'src/app/logging-contants';
import { BlogPost } from 'src/app/models/blog-post.model';
import { BlogPostService } from 'src/app/services/blog-post.service';


@Component({
  selector: 'app-admin-view-blog',
  templateUrl: './admin-view-blog.component.html',
  styleUrls: ['./admin-view-blog.component.css']
})
export class AdminViewBlogComponent implements OnInit {
  blogPosts: BlogPost[] = [];
  blogPost: BlogPost = {} as BlogPost;
  id: number = 0;

  constructor(
    private readonly blogPostService: BlogPostService,
    private readonly activatedRoute: ActivatedRoute,
    private readonly loggerService: LoggerService  // Inject the logger service
  ) {}

  ngOnInit(): void {
    this.loadBlogPosts();
  }

  loadBlogPosts(): void {
    this.blogPostService.getAllBlogPosts().subscribe(
      data => {
        this.blogPosts = data.map(post => ({
          ...post,
          status: post.status || 'Pending'
        }));
        this.loggerService.log(LOGGING_MESSAGES.BLOGPOST_LOAD_SUCCESS);
      },
      error => {
        this.loggerService.error(LOGGING_MESSAGES.BLOGPOST_LOAD_FAILURE);
      }
    );
  }

  deleteBlogPost(id: number): void {
    this.blogPostService.deleteBlogPost(id).subscribe(
      response => {
        this.blogPosts = this.blogPosts.filter(post => post.blogPostId !== id);
        this.loggerService.log(LOGGING_MESSAGES.BLOGPOST_DELETE_SUCCESS);
      },
      error => {
        this.loggerService.error(LOGGING_MESSAGES.BLOGPOST_DELETE_FAILURE);
      }
    );
  }

  approveBlogPost(id: number): void {
    this.blogPostService.getBlogPostByPostId(id).subscribe(
      post => {
        post.status = 'Approved';
        this.blogPostService.updateBlogPost(post).subscribe(
          response => {
            const updatedPost = this.blogPosts.find(p => p.blogPostId === id);
            if (updatedPost) {
              updatedPost.status = 'Approved';
            }
            this.loggerService.log(LOGGING_MESSAGES.BLOGPOST_APPROVE_SUCCESS);
          },
          error => {
            this.loggerService.error(LOGGING_MESSAGES.BLOGPOST_APPROVE_FAILURE);
          }
        );
      },
      error => {
        this.loggerService.error(LOGGING_MESSAGES.BLOGPOST_LOAD_FAILURE);
      }
    );
  }
}

