import { Component } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { AuthService } from 'src/app/services/auth.service';
import { LoggerService } from 'src/app/logger.service';
import { LOGGING_MESSAGES } from 'src/app/logging-contants';
import { Login } from 'src/app/models/login.model';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent {
  loginForm: FormGroup;
  errorMessage:string='';
  constructor(
    private readonly formBuilder: FormBuilder,
    private readonly service: AuthService,
    private readonly router: Router,
    private readonly loggerService: LoggerService 
  ) {
    this.loginForm = this.formBuilder.group({
      email: ['', [Validators.required, Validators.email]],
      password: ['', [Validators.required]],
    });
    this.loggerService.log(LOGGING_MESSAGES.LOGIN_FORM_INIT);
  }

  get f() {
    return this.loginForm.controls;
  }

  login() {
    if (this.loginForm.valid) {
      this.service.login(this.loginForm.value).subscribe((res: any) => {
        console.log(res.jwtToken + " " + res.role);
        const authUser: Login = <Login>res;
        this.service.setAuthUser(authUser);
        this.loggerService.log(LOGGING_MESSAGES.LOGIN_FORM_SUBMIT_SUCCESS);

        if (this.service.isAdmin()) {
          this.router.navigate(['/admin-navbar']);
          this.loggerService.log(LOGGING_MESSAGES.NAVIGATE_ADMIN_DASHBOARD);
          this.router.navigate(['/admin-dashboard']);
          this.loggerService.log("in dashboard");
        } 
        else if (this.service.isUser()) {
          this.router.navigate(['/user-navbar']);
          this.loggerService.log(LOGGING_MESSAGES.NAVIGATE_USER_DASHBOARD);
          this.router.navigate(['/user-dashboard']);
        }
      }, error => {
        this.errorMessage="Invalid Credentials! Please Try Again.";
        this.loggerService.error(LOGGING_MESSAGES.LOGIN_FORM_SUBMIT_FAILURE);
      });
    }
  }
}

