import { ComponentFixture, TestBed } from '@angular/core/testing';

import { UserViewAnnouncementComponent } from './user-view-announcement.component';

describe('UserViewAnnouncementComponent', () => {
  let component: UserViewAnnouncementComponent;
  let fixture: ComponentFixture<UserViewAnnouncementComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ UserViewAnnouncementComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(UserViewAnnouncementComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
