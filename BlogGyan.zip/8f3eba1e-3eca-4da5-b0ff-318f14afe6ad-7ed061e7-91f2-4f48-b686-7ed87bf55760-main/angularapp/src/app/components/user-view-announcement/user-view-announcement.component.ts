import { Component, OnInit } from '@angular/core';
import { Announcement } from 'src/app/models/announcement.model';
import { AnnouncementService } from 'src/app/services/announcement.service';
import { LoggerService } from 'src/app/logger.service'; 
import { LOGGING_MESSAGES } from 'src/app/logging-contants';

@Component({
  selector: 'app-user-view-announcement',
  templateUrl: './user-view-announcement.component.html',
  styleUrls: ['./user-view-announcement.component.css']
})
export class UserViewAnnouncementComponent implements OnInit {
  announcementsList: Announcement[] = [];
  filteredAnnouncements: Announcement[] = [];
  searchTerm: string = '';

  constructor(
    private readonly announcementService: AnnouncementService,
    private readonly loggerService: LoggerService 
  ) { }

  ngOnInit(): void {
    this.loadAnnouncements();
  }

  loadAnnouncements(): void {
    this.announcementService.getAllAnnouncements().subscribe((data) => {
      this.announcementsList = data.filter((d)=>d.status.toUpperCase()==="ACTIVE");
      this.filteredAnnouncements = data;
      this.loggerService.log(LOGGING_MESSAGES.ANNOUNCEMENT_VIEW_SUCCESS);
    }, error => {
      this.loggerService.error(LOGGING_MESSAGES.ANNOUNCEMENT_VIEW_FAILURE);
    });
  }

  filterAnnouncements(): void {
    this.filteredAnnouncements = this.announcementsList.filter(announcement =>
      announcement.title.toLowerCase().includes(this.searchTerm.toLowerCase()) ||
      announcement.content.toLowerCase().includes(this.searchTerm.toLowerCase()) ||
      announcement.category.toLowerCase().includes(this.searchTerm.toLowerCase())
    );
    this.loggerService.log(LOGGING_MESSAGES.ANNOUNCEMENT_FILTER_USER);
  }
}

