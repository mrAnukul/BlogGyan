import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { LoggerService } from 'src/app/logger.service';
import { LOGGING_MESSAGES } from 'src/app/logging-contants';
import { Announcement } from 'src/app/models/announcement.model';
import { AnnouncementService } from 'src/app/services/announcement.service';


@Component({
  selector: 'app-admin-view-announcement',
  templateUrl: './admin-view-announcement.component.html',
  styleUrls: ['./admin-view-announcement.component.css']
})
export class AdminViewAnnouncementComponent implements OnInit {
  announcementsList: Announcement[] = [];
  filteredAnnouncements: Announcement[] = [];
  searchTerm: string = '';
  announcement: Announcement;
  showDeletePopup: boolean=false;

  constructor(
    private readonly announcementService: AnnouncementService,
    private readonly router: Router,
    private readonly loggerService: LoggerService 
  ) {}

  ngOnInit(): void {
    this.loadAnnouncements();
  }

  loadAnnouncements(): void {
    this.announcementService.getAllAnnouncements().subscribe((data) => {
      this.announcementsList = data;
      this.filteredAnnouncements = data;
      this.loggerService.log(LOGGING_MESSAGES.ANNOUNCEMENT_LOAD_SUCCESS);
    }, error => {
      this.loggerService.error(LOGGING_MESSAGES.ANNOUNCEMENT_LOAD_FAILURE);
    });
  }

  editAnnouncement(announcement: Announcement): void {
    this.router.navigate(['/admin-add-announcement', announcement.announcementId]);
  }

  deleteAnnouncement(id: number): void {
    this.announcementService.deleteAnnouncement(id).subscribe(() => {
      this.loadAnnouncements();
      this.loggerService.log(LOGGING_MESSAGES.ANNOUNCEMENT_DELETE_SUCCESS);
    }, error => {
      this.loggerService.error(LOGGING_MESSAGES.ANNOUNCEMENT_DELETE_FAILURE);
    });
  }

  filterAnnouncements(): void {
    this.filteredAnnouncements = this.announcementsList.filter(announcement =>
      announcement.title.toLowerCase().includes(this.searchTerm.toLowerCase()) ||
      announcement.content.toLowerCase().includes(this.searchTerm.toLowerCase())||
      announcement.category.toLowerCase().includes(this.searchTerm.toLowerCase())||
      announcement.status.toLowerCase().includes(this.searchTerm.toLowerCase())||
      announcement.priority.toLowerCase().includes(this.searchTerm.toLowerCase())
    );
    this.loggerService.log(LOGGING_MESSAGES.ANNOUNCEMENT_FILTER);
  }
  confirmDelete(announcement:Announcement) {
    this.announcement = announcement;
    document.body.classList.add('blur');
    this.showDeletePopup = true;
  }
 
  deleteItem(announcement:Announcement) {
    console.log('Item deleted');
    this.deleteAnnouncement(announcement.announcementId);
    this.showDeletePopup = false;
  }
 
  closeDeletePopup() {
    document.body.classList.remove('blur');
    this.showDeletePopup = false;
  }
}

