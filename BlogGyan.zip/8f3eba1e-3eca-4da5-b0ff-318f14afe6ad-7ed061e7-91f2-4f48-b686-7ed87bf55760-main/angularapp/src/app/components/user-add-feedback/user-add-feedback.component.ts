import { Component } from '@angular/core';
import { FormBuilder, FormControl, FormGroup, Validators } from '@angular/forms';
import { Feedback } from 'src/app/models/feedback.model';
import { FeedbackService } from 'src/app/services/feedback.service';
import { LoggerService } from 'src/app/logger.service';
import { LOGGING_MESSAGES } from 'src/app/logging-contants';
import { Router } from '@angular/router';
import { AuthService } from 'src/app/services/auth.service';

@Component({
  selector: 'app-user-add-feedback',
  templateUrl: './user-add-feedback.component.html',
  styleUrls: ['./user-add-feedback.component.css']
})
export class UserAddFeedbackComponent  {
  feedbackForm: FormGroup;
  showPopup: boolean = false;

  constructor(
    private readonly fb: FormBuilder,
    private readonly service: FeedbackService,
    private readonly loggerService: LoggerService ,
    private readonly authService:AuthService,
    private router:Router
  ) {
    this.createForm();
  }

  createForm() {
    this.feedbackForm = this.fb.group({
      feedbackText: new FormControl(null, [Validators.required])
    });
  }

  get feedbackText() {
    return this.feedbackForm.get('feedbackText');
  }

  closePopup() {
    this.showPopup = false;
    // this.feedbackForm.reset();
    this.router.navigate(['/user-view-feedback']);
    
  }

  addFeedback() {
    const userId = this.authService.getAuthUser()?.userId;
    if (userId) {
      const feedback: Feedback = {
        ...this.feedbackForm.value,
        user: { userId: +userId }
      };
      console.log(feedback);
      this.service.sendFeedBack(feedback).subscribe(
        () => {
          this.loggerService.log(LOGGING_MESSAGES.FEEDBACK_LOAD_SUCCESS);
          this.showPopup = true;
        },
        error => {
          this.loggerService.error(LOGGING_MESSAGES.FEEDBACK_LOAD_FAILURE);
          this.showPopup = true;
        }
      );
    } else {
      console.error('User ID not found in local storage');
    }
  }
}

