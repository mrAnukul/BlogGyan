import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormControl, FormGroup, Validators } from '@angular/forms';
import { ActivatedRoute, Router } from '@angular/router';
import { BlogPost } from 'src/app/models/blog-post.model';
import { BlogPostService } from 'src/app/services/blog-post.service';
import { LoggerService } from 'src/app/logger.service'; 
import { LOGGING_MESSAGES } from 'src/app/logging-contants';
import { AuthService } from 'src/app/services/auth.service';


@Component({
  selector: 'app-user-add-blog',
  templateUrl: './user-add-blog.component.html',
  styleUrls: ['./user-add-blog.component.css']
})
export class UserAddBlogComponent implements OnInit {

  addBlogPostForm: FormGroup;
  isUpdateMode: boolean = false;
  currentBlogPostId: number | null = null;

  constructor(
    private readonly service: BlogPostService,
    private readonly fb: FormBuilder,
    private readonly route: Router,
    private readonly activatedRoute: ActivatedRoute,
    private readonly authService:AuthService,
    private readonly loggerService: LoggerService  // Inject the logger service
  ) { }

  ngOnInit(): void {
    this.addBlogPostForm=this.fb.group({
      title:new FormControl(null,[Validators.required,Validators.minLength(1),Validators.maxLength(100)]),
      content:new FormControl(null,[Validators.required,Validators.minLength(1),Validators.maxLength(1000)])
    })

    this.activatedRoute.params.subscribe(params => {
      const id = params['id'];
      if (id) {
        this.isUpdateMode = true;
        this.currentBlogPostId = +id;
        this.loadBlogPostData(this.currentBlogPostId);
      }
    });
  }

  get f() {
    return this.addBlogPostForm.controls;
  }

  loadBlogPostData(id: number): void {
    this.service.getBlogPostByPostId(id).subscribe((data: BlogPost) => {
      this.addBlogPostForm.patchValue(data);
      this.loggerService.log(LOGGING_MESSAGES.BLOGPOST_LOAD_DATA_SUCCESS);
    }, error => {
      this.loggerService.error(LOGGING_MESSAGES.BLOGPOST_LOAD_DATA_FAILURE);
    });
  }

  saveBlogPost(): void {
    const userId = this.authService.getAuthUser()?.userId;
    if (!userId) {
      console.error('User ID not found in local storage');
      return;
    }

    const blogPost: BlogPost = {
      ...this.addBlogPostForm.value,
      user: { userId: +userId }
    };

    if (this.isUpdateMode && this.currentBlogPostId !== null) {
      blogPost.blogPostId = this.currentBlogPostId;
      this.service.updateBlogPost(blogPost).subscribe(() => {
        this.loggerService.log(LOGGING_MESSAGES.BLOGPOST_UPDATE_SUCCESS);
        this.route.navigate(['/user-view-blog']);
      }, error => {
        this.loggerService.error(LOGGING_MESSAGES.BLOGPOST_UPDATE_FAILURE);
      });
    } else {
      this.service.addBlogPost(blogPost).subscribe(() => {
        this.loggerService.log(LOGGING_MESSAGES.BLOGPOST_SAVE_SUCCESS);
        this.route.navigate(['/user-view-blog']);
      }, error => {
        this.loggerService.error(LOGGING_MESSAGES.BLOGPOST_SAVE_FAILURE);
      });
    }
  }

  cancelBlog(): void {
    this.route.navigate(['/user-view-blog']);
  }
}
