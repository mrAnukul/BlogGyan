import { ComponentFixture, TestBed } from '@angular/core/testing';

import { UserAddBlogComponent } from './user-add-blog.component';

describe('UserAddBlogComponent', () => {
  let component: UserAddBlogComponent;
  let fixture: ComponentFixture<UserAddBlogComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ UserAddBlogComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(UserAddBlogComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
