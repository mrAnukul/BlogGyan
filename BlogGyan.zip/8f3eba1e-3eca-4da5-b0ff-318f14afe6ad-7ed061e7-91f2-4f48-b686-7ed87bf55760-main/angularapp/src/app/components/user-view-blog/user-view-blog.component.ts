import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { BlogPost } from 'src/app/models/blog-post.model';
import { Feedback } from 'src/app/models/feedback.model';
import { BlogPostService } from 'src/app/services/blog-post.service';
import { LoggerService } from 'src/app/logger.service'; 
import { LOGGING_MESSAGES } from 'src/app/logging-contants';
import { AuthService } from 'src/app/services/auth.service';


@Component({
  selector: 'app-user-view-blog',
  templateUrl: './user-view-blog.component.html',
  styleUrls: ['./user-view-blog.component.css']
})
export class UserViewBlogComponent implements OnInit {
  myBlogPostList:BlogPost[]=[];
  filteredBlogPost: BlogPost[] = [];
  searchTerm: string = '';
  showDeletePopup: boolean = false;
  isExpanded = false;
  blogPost: BlogPost;
  userId:number;
  constructor(
    private readonly blogPostService: BlogPostService,
    private readonly router: Router,
    private readonly authService:AuthService,
    private readonly loggerService: LoggerService  
  ) { }

  ngOnInit(): void {
    this.userId = this.authService.getAuthUser()?.userId; // Get the userId from local storage
    this.loadBlogPost();
  }

  loadBlogPost(): void {
    this.blogPostService.getBlogPostByUserId(this.userId).subscribe((data)=>{
      this.myBlogPostList=data;
      this.filteredBlogPost = data;
      this.loggerService.log(LOGGING_MESSAGES.BLOGPOST_VIEW_SUCCESS);
    }, error => {
      this.loggerService.error(LOGGING_MESSAGES.BLOGPOST_VIEW_FAILURE);
    });
  }

  updateBlogPost(id: number): void {
    this.router.navigate(['/user-add-blog', id]);
  }

  deleteBlogPost(id: number): void {
    this.blogPostService.deleteBlogPost(id).subscribe(() => {
      this.loadBlogPost();
      this.loggerService.log(LOGGING_MESSAGES.BLOGPOST_DELETE_USER_SUCCESS);
    }, error => {
      this.loggerService.error(LOGGING_MESSAGES.BLOGPOST_DELETE_USER_FAILURE);
    });
  }

  filterBlogPost(): void {
    this.filteredBlogPost = this.myBlogPostList.filter(blogPost =>
      blogPost.title.toLowerCase().includes(this.searchTerm.toLowerCase()) ||
      blogPost.content.toLowerCase().includes(this.searchTerm.toLowerCase())
    );
    this.loggerService.log(LOGGING_MESSAGES.BLOGPOST_FILTER_USER);
  }

  confirmDelete(blogPost: BlogPost) {
    this.blogPost = blogPost;
    document.body.classList.add('blur');
    this.showDeletePopup = true;
  }
 
  deleteItem(blogPost:BlogPost) {
    console.log('Item deleted');
    this.deleteBlogPost(blogPost.blogPostId);
    this.showDeletePopup = false;
  }

  closeDeletePopup() {
    document.body.classList.remove('blur');
    this.showDeletePopup = false;
  }
}
