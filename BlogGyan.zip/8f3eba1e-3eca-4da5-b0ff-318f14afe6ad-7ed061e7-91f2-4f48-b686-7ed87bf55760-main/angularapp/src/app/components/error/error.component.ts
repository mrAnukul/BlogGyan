import { Component } from '@angular/core';
import { LoggerService } from 'src/app/logger.service';
import { LOGGING_MESSAGES } from 'src/app/logging-contants';
import { AuthService } from 'src/app/services/auth.service';


@Component({
  selector: 'app-error',
  templateUrl: './error.component.html',
  styleUrls: ['./error.component.css']
})
export class ErrorComponent  {

  constructor(
    private readonly authService: AuthService,
    private readonly loggerService: LoggerService  // Inject the logger service
  ) {
    this.loggerService.log(LOGGING_MESSAGES.ERROR_PAGE_INIT);
  }

  logout() {
    localStorage.clear();
    this.loggerService.log(LOGGING_MESSAGES.LOGOUT_SUCCESS);
  }
}
