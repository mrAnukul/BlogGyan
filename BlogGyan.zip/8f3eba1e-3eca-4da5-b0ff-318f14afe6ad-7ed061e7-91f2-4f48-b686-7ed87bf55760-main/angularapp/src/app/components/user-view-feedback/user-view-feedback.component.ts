import { Component, OnInit } from '@angular/core';
import { Feedback } from 'src/app/models/feedback.model';
import { FeedbackService } from 'src/app/services/feedback.service';
import { LoggerService } from 'src/app/logger.service';
import { LOGGING_MESSAGES } from 'src/app/logging-contants';
import { AuthService } from 'src/app/services/auth.service';


@Component({
  selector: 'app-user-view-feedback',
  templateUrl: './user-view-feedback.component.html',
  styleUrls: ['./user-view-feedback.component.css']
})
export class UserViewFeedbackComponent implements OnInit {
  feedbackList: Feedback[] = [];
  feedback: Feedback;
  showDeletePopup: boolean = false;
  userId: number;

  constructor(
    private readonly feedbackService: FeedbackService,
    private readonly loggerService: LoggerService,
    private readonly authService:AuthService
  ) {}

  ngOnInit(): void {
    const userId = this.authService.getAuthUser()?.userId;
    if (userId) {
      this.userId = +userId;
      this.loggerService.log(`User ID: ${this.userId}`);
      this.loadFeedback();
    } else {
      console.error('User ID not found in local storage');
      this.loggerService.error('User ID not found in local storage');
    }
  }

  loadFeedback(): void {
    this.feedbackService.getAllFeedbacksByUserId(this.userId).subscribe((data) => {
      this.feedbackList = data;
      this.loggerService.log(LOGGING_MESSAGES.FEEDBACK_VIEW_SUCCESS);
    },
    error => {
      this.loggerService.error(LOGGING_MESSAGES.FEEDBACK_VIEW_FAILURE);
    });
  }

  deleteFeedback(id: number): void {
    this.feedbackService.deleteFeedback(id).subscribe(() => {
      this.loadFeedback();
      this.loggerService.log(LOGGING_MESSAGES.FEEDBACK_DELETE_USER_SUCCESS);
    }, error => {
      this.loggerService.error(LOGGING_MESSAGES.FEEDBACK_DELETE_USER_FAILURE);
    });
  }

  confirmDelete(feedback: Feedback) {
    this.feedback = feedback;
    document.body.classList.add('blur');
    this.showDeletePopup = true;
  }

  deleteItem(feedback:Feedback) {
    console.log('Item deleted');
    this.deleteFeedback(feedback.feedbackId);
    this.showDeletePopup = false;
  }

  closeDeletePopup() {
    document.body.classList.remove('blur');
    this.showDeletePopup = false;
  }
}
