import { Component } from '@angular/core';
import { AbstractControl, FormBuilder, FormControl, FormGroup, ValidationErrors, ValidatorFn, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { AuthService } from 'src/app/services/auth.service';
import { LoggerService } from 'src/app/logger.service';  
import { LOGGING_MESSAGES } from 'src/app/logging-contants';

@Component({
  selector: 'app-registration',
  templateUrl: './registration.component.html',
  styleUrls: ['./registration.component.css']
})
export class RegistrationComponent  {
  registerForm: FormGroup;
  msg='';
  errorMessage:string='';
  successMessage:string='';

  constructor(
    private readonly Authservice: AuthService,
    private readonly fb: FormBuilder,
    private readonly router: Router,
    private readonly loggerService: LoggerService  
  ) {
    this.createForm();
    this.loggerService.log(LOGGING_MESSAGES.REGISTER_FORM_INIT);
  }

  createForm() {
    this.registerForm = this.fb.group({
      username: new FormControl(null, [Validators.required]),
      email: new FormControl(null, [Validators.required, Validators.email]),
      password: new FormControl(null, [Validators.required, Validators.pattern(/^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)(?=.*[@$!%*?&])[A-Za-z\d@$!%*?&]{8,}$/)]),
      confirmPassword: new FormControl(null, [Validators.required]),
      mobileNumber: new FormControl(null, [Validators.required, Validators.pattern('^[0-9]{10}$')]),
      role: new FormControl(null, [Validators.required])
    }, {
      validators: [validatePassword()]
    });
  }

  get username() {
    return this.registerForm.get('username');
  }

  get email() {
    return this.registerForm.get('email');
  }

  get password() {
    return this.registerForm.get('password');
  }

  get confirmPassword() {
    return this.registerForm.get('confirmPassword');
  }

  get mobileNumber() {
    return this.registerForm.get('mobileNumber');
  }

  get role() {
    return this.registerForm.get('role');
  }

  register() {
    if (this.registerForm.valid) {
      this.Authservice.register(this.registerForm.value).subscribe(() => {
        this.successMessage = 'Registration successful!';
        this.loggerService.log(LOGGING_MESSAGES.REGISTER_FORM_SUBMIT_SUCCESS);
        this.router.navigate(['/login']);
      }, error => {
        this.errorMessage = 'Registration failed. Please try again.';
        this.loggerService.error(LOGGING_MESSAGES.REGISTER_FORM_SUBMIT_FAILURE);
      });
    }
  }
}

export function validatePassword(): ValidatorFn {
  return (formGroup: AbstractControl): ValidationErrors | null => {
    const ctl1 = formGroup.get("password");
    const ctl2 = formGroup.get("confirmPassword");
    if (!ctl1 || !ctl2) {
      console.log('In passwordValidator, ctl1 and ctl2 are null');
      return null;
    }
    const pw1 = ctl1.value;
    const pw2 = ctl2.value;
    return pw1 === pw2 ? null : { passwordMismatch: true };
  }
}

