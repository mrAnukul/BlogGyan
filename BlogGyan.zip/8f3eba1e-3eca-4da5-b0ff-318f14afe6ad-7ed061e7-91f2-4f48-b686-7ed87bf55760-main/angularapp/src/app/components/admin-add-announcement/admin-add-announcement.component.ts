import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { ActivatedRoute, Router } from '@angular/router';
import { LoggerService } from 'src/app/logger.service';
import { LOGGING_MESSAGES } from 'src/app/logging-contants';
import { Announcement } from 'src/app/models/announcement.model';
import { AnnouncementService } from 'src/app/services/announcement.service';


@Component({
  selector: 'app-admin-add-announcement',
  templateUrl: './admin-add-announcement.component.html',
  styleUrls: ['./admin-add-announcement.component.css']
})
export class AdminAddAnnouncementComponent implements OnInit {

  announcementForm: FormGroup;
  isUpdateMode: boolean = false;
  currentAnnouncementId: number | null = null;

  constructor(
    private readonly fb: FormBuilder,
    private readonly announcementService: AnnouncementService,
    private readonly route: Router,
    private readonly activatedRoute: ActivatedRoute,
    private readonly loggerService: LoggerService
  ) {
    this.announcementForm = this.fb.group({
      title: ['', Validators.required],
      content: ['', Validators.required],
      status: ['', Validators.required],
      category: ['', Validators.required],
      priority: ['', Validators.required],
      publishedDate: ['', Validators.required]
    });
  }

  ngOnInit(): void {
    this.activatedRoute.params.subscribe(params => {
      const id = params['id'];
      if (id) {
        this.isUpdateMode = true;
        this.currentAnnouncementId = +id;
        this.loadAnnouncementData(this.currentAnnouncementId);
      }
    });
  }

  get f() {
    return this.announcementForm.controls;
  }

  loadAnnouncementData(id: number): void {
    this.announcementService.getAnnouncementById(id).subscribe((data: Announcement) => {
      this.announcementForm.patchValue(data);
      this.loggerService.log(LOGGING_MESSAGES.ANNOUNCEMENT_LOAD_SUCCESS);
    }, error => {
      this.loggerService.error(LOGGING_MESSAGES.ANNOUNCEMENT_LOAD_FAILURE);
    });
  }

  saveAnnouncement(): void {
    if (this.announcementForm.valid) {
      const announcement: Announcement = this.announcementForm.value;
      
      if (this.isUpdateMode && this.currentAnnouncementId !== null) {
        this.announcementService.updateAnnouncement(this.currentAnnouncementId, announcement).subscribe(
          (response) => {
            this.loggerService.log(LOGGING_MESSAGES.ANNOUNCEMENT_UPDATE_SUCCESS);
            this.route.navigate(['/admin-view-announcement']);
          },
          error => {
            console.error('Error updating announcement:', error);
            this.loggerService.error(LOGGING_MESSAGES.ANNOUNCEMENT_UPDATE_FAILURE);
          }
        );
      } else {
        this.announcementService.addAnnouncement(announcement).subscribe(
          (response) => {
            this.loggerService.log(LOGGING_MESSAGES.ANNOUNCEMENT_ADD_SUCCESS);
            this.announcementForm.reset();
            this.route.navigate(['/admin-view-announcement']);
          },
          error => {
            console.error('Error adding announcement:', error);
            this.loggerService.error(LOGGING_MESSAGES.ANNOUNCEMENT_ADD_FAILURE);
          }
        );
      }
    }
  }
}
