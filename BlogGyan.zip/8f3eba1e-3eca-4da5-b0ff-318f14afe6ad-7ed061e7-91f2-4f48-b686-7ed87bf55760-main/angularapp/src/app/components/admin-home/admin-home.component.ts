import { Component, OnInit } from '@angular/core';
import { LoggerService } from 'src/app/logger.service';
import { LOGGING_MESSAGES } from 'src/app/logging-contants';
import { Announcement } from 'src/app/models/announcement.model';
import { BlogPost } from 'src/app/models/blog-post.model';
import { User } from 'src/app/models/user.model';
import { AnnouncementService } from 'src/app/services/announcement.service';
import { AuthService } from 'src/app/services/auth.service';
import { BlogPostService } from 'src/app/services/blog-post.service';


@Component({
  selector: 'app-admin-home',
  templateUrl: './admin-home.component.html',
  styleUrls: ['./admin-home.component.css']
})
export class AdminHomeComponent implements OnInit {
  blogList: BlogPost[];
  count: number;
  users: User[];
  userCount: number;
  announcements: Announcement[];
  announementCount: number;

  constructor(
    private readonly blogPostService: BlogPostService,
    private readonly authService: AuthService,
    private readonly announcementService: AnnouncementService,
    private readonly loggerService: LoggerService  
  ) { }

  ngOnInit(): void {
    this.getAllBlogPosts();
    this.getAllUsers();
    this.getAllAnnouncements();
  }

  getAllBlogPosts() {
    this.blogPostService.getAllBlogPosts().subscribe((data) => {
      this.blogList = data;
      this.count = this.blogList.length;
      this.loggerService.log(LOGGING_MESSAGES.BLOGPOST_LOAD_SUCCESS);
    }, error => {
      this.loggerService.error(LOGGING_MESSAGES.BLOGPOST_LOAD_FAILURE);
    });
  }

  getAllUsers() {
    this.authService.getAllUsers().subscribe((data) => {
      this.users = data;
      this.userCount = this.users.filter(user => user.role.toLowerCase() === 'user').length;
      this.loggerService.log(LOGGING_MESSAGES.USER_LOAD_SUCCESS);
    }, error => {
      this.loggerService.error(LOGGING_MESSAGES.USER_LOAD_FAILURE);
    });
  }

  getAllAnnouncements() {
    this.announcementService.getAllAnnouncements().subscribe((data) => {
      this.announcements = data;
      this.announementCount = this.announcements.length;
      this.loggerService.log(LOGGING_MESSAGES.ANNOUNCEMENT_LOAD_SUCCESS);
    }, error => {
      this.loggerService.error(LOGGING_MESSAGES.ANNOUNCEMENT_LOAD_FAILURE);
    });
  }
}

