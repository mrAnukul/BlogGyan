import { Component, OnInit } from '@angular/core';
import { AuthService } from 'src/app/services/auth.service';
import { BlogPostService } from 'src/app/services/blog-post.service';
import { Router } from '@angular/router';
import { LoggerService } from 'src/app/logger.service';
import { LOGGING_MESSAGES } from 'src/app/logging-contants';


@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.css']
})
export class HomeComponent implements OnInit {
  topBlogPosts: any[] = [];

  constructor(
    private readonly authService: AuthService,
    private readonly blogPostService: BlogPostService,
    private readonly router: Router,
    private readonly loggerService: LoggerService  
  ) {
    this.loggerService.log(LOGGING_MESSAGES.HOME_INIT);
  }

  ngOnInit(): void {
    this.loadTopBlogPosts();
  }

  user(): boolean {
    return this.authService.isUser();
  }

  admin(): boolean {
    return this.authService.isAdmin();
  }
  isLoggedIn():boolean{
    return !this.authService.isLoggedIn();
  }

  loadTopBlogPosts(): void {
    this.blogPostService.getAllBlogPosts().subscribe(posts => {
      this.topBlogPosts = posts.slice(0, 5); // Get top 5 blog posts
      this.loggerService.log(LOGGING_MESSAGES.TOP_BLOGPOSTS_LOAD_SUCCESS);
    }, error => {
      this.loggerService.error(LOGGING_MESSAGES.TOP_BLOGPOSTS_LOAD_FAILURE);
    });
  }

  viewBlogPost(blogPostId: number): void {
    if (!this.authService.isLoggedIn()) {
      this.loggerService.warn(LOGGING_MESSAGES.VIEW_BLOGPOST_UNREGISTERED);
      this.router.navigate(['/register']);
    } else {
      this.loggerService.log(LOGGING_MESSAGES.VIEW_BLOGPOST);
      this.router.navigate(['/blog-post', blogPostId]);
    }
  }

  handleKeyPress(event: KeyboardEvent, blogPostId: number): void {
    if (event.key === 'Enter') {
      this.viewBlogPost(blogPostId);
    }
  }
}

