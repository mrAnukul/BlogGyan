import { Component } from '@angular/core';
import { Router } from '@angular/router';
import { AuthService } from 'src/app/services/auth.service';
import { LoggerService } from 'src/app/logger.service'; 
import { LOGGING_MESSAGES } from 'src/app/logging-contants';


@Component({
  selector: 'app-user-navbar',
  templateUrl: './user-navbar.component.html',
  styleUrls: ['./user-navbar.component.css']
})
export class UserNavbarComponent  {
  userName: string = this.authService.getUserName();

  constructor(
    private readonly authService: AuthService,
    private readonly router: Router,
    private readonly loggerService: LoggerService  // Inject the logger service
  ) {
    this.loggerService.log(LOGGING_MESSAGES.USER_NAVBAR_INIT);
  }

  logout() {
    this.authService.logout();
    localStorage.clear();
    this.router.navigate(['/login']);
    this.loggerService.log(LOGGING_MESSAGES.LOGOUT_SUCCESS);
  }
}
