import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { LoggerService } from 'src/app/logger.service';
import { LOGGING_MESSAGES } from 'src/app/logging-contants';
import { BlogPost } from 'src/app/models/blog-post.model';
import { Feedback } from 'src/app/models/feedback.model';
import { BlogPostService } from 'src/app/services/blog-post.service';
import { FeedbackService } from 'src/app/services/feedback.service';


@Component({
  selector: 'app-admin-view-feedback',
  templateUrl: './admin-view-feedback.component.html',
  styleUrls: ['./admin-view-feedback.component.css']
})
export class AdminViewFeedbackComponent implements OnInit {

  FeedbackList: Feedback[] = [];
  selectedUser: any = null;
  blogList: BlogPost[] = [];
  count: number = 0;

  constructor(
    private readonly feedbackService: FeedbackService,
    private readonly router: Router,
    private readonly blogPostService:BlogPostService,
    private readonly loggerService: LoggerService  
  ) {}

  ngOnInit(): void {
    this.loadFeedback();
  }

  loadFeedback(): void {
    this.feedbackService.getFeedbacks().subscribe((data) => {
      this.FeedbackList = data;
      this.loggerService.log(LOGGING_MESSAGES.FEEDBACK_LOAD_SUCCESS);
    }, error => {
      this.loggerService.error(LOGGING_MESSAGES.FEEDBACK_LOAD_FAILURE);
    });
  }

  showUserProfile(user: any): void {
    this.selectedUser = user;
    this.getAllBlogPosts(user.userId);
  }

  getAllBlogPosts(userId: number): void {
    this.blogPostService.getBlogPostByUserId(userId).subscribe((data) => {
      this.blogList = data;
      this.count = this.blogList.length;
    });
  }

  closeUserProfile(): void {
    this.selectedUser = null;
    this.blogList = [];
    this.count = 0;
  }
}

